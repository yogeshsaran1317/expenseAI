import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import {
  Expense,
  IncomeItem,
  CategoryBudget,
  FinancialGoal,
  Subscription,
  Bill,
  AchievementBadge,
  SavingsChallenge,
  AppNotification,
  ActivityLog,
  UserProfile,
  CurrencyCode,
  WalletType,
} from "../types";
import {
  CURRENCIES,
  INITIAL_USER,
  INITIAL_EXPENSES,
  INITIAL_INCOME,
  INITIAL_CATEGORY_BUDGETS,
  INITIAL_GOALS,
  INITIAL_SUBSCRIPTIONS,
  INITIAL_BILLS,
  INITIAL_ACHIEVEMENTS,
  INITIAL_CHALLENGES,
  INITIAL_NOTIFICATIONS,
  INITIAL_LOGS,
} from "../data/mockData";
import confetti from "canvas-confetti";

export type NavTab =
  | "landing"
  | "dashboard"
  | "expenses"
  | "income"
  | "budget"
  | "ai-cfo"
  | "analytics"
  | "goals"
  | "subscriptions"
  | "bills"
  | "calculators"
  | "rewards"
  | "journal"
  | "security"
  | "admin";

interface ExpenseContextType {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  theme: "dark" | "light";
  toggleTheme: () => void;
  selectedCurrency: CurrencyCode;
  setSelectedCurrency: (code: CurrencyCode) => void;
  selectedWallet: WalletType | "all";
  setSelectedWallet: (wallet: WalletType | "all") => void;
  formatCurrency: (amount: number) => string;
  
  // Auth state
  isLoggedIn: boolean;
  login: (email: string, pass: string) => boolean;
  logout: () => void;
  user: UserProfile;
  updateUserProfile: (updated: Partial<UserProfile>) => void;
  
  // Data
  expenses: Expense[];
  incomeList: IncomeItem[];
  budgets: CategoryBudget[];
  goals: FinancialGoal[];
  subscriptions: Subscription[];
  bills: Bill[];
  achievements: AchievementBadge[];
  challenges: SavingsChallenge[];
  notifications: AppNotification[];
  logs: ActivityLog[];
  
  // Actions
  addExpense: (exp: Omit<Expense, "id">) => void;
  addBulkExpenses: (expList: Omit<Expense, "id">[]) => void;
  editExpense: (id: string, exp: Partial<Expense>) => void;
  deleteExpense: (id: string) => void;
  duplicateExpense: (id: string) => void;
  bulkDeleteExpenses: (ids: string[]) => void;
  
  addIncome: (inc: Omit<IncomeItem, "id">) => void;
  editIncome: (id: string, inc: Partial<IncomeItem>) => void;
  deleteIncome: (id: string) => void;
  updateSalary: (amount: number) => void;
  
  updateBudget: (category: string, newLimit: number) => void;
  
  addGoal: (goal: Omit<FinancialGoal, "id" | "currentAmount">) => void;
  addGoalContribution: (goalId: string, amount: number) => void;
  deleteGoal: (id: string) => void;
  
  addSubscription: (sub: Omit<Subscription, "id">) => void;
  deleteSubscription: (id: string) => void;
  
  toggleBillPaid: (id: string) => void;
  addBill: (bill: Omit<Bill, "id" | "isPaid">) => void;
  
  markNotificationRead: (id: string) => void;
  clearAllNotifications: () => void;
  addNotification: (title: string, message: string, type: "alert" | "info" | "success" | "warning") => void;
  addLog: (action: string, detail: string, type: ActivityLog["type"]) => void;
  
  // Computed Financial Metrics
  metrics: {
    totalBalance: number;
    monthlyIncome: number;
    monthlyExpense: number;
    monthlySavings: number;
    savingsRate: number;
    netWorth: number;
    creditScore: number;
    financialHealthScore: number;
    budgetRemaining: number;
    totalInvestments: number;
    emergencyFundAmount: number;
    monthlyCashFlow: number;
  };
  
  globalSearch: string;
  setGlobalSearch: (q: string) => void;
  isAiModalOpen: boolean;
  setIsAiModalOpen: (open: boolean) => void;
}

const ExpenseContext = createContext<ExpenseContextType | undefined>(undefined);

export const ExpenseProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [activeTab, setActiveTab] = useState<NavTab>("dashboard");
  const [theme, setTheme] = useState<"dark" | "light">(() => {
    return (localStorage.getItem("expenseos_theme") as "dark" | "light") || "dark";
  });
  const [selectedCurrency, setSelectedCurrency] = useState<CurrencyCode>(() => {
    const saved = localStorage.getItem("expenseos_currency");
    return (saved as CurrencyCode) || "INR";
  });

  useEffect(() => {
    localStorage.setItem("expenseos_currency", selectedCurrency);
  }, [selectedCurrency]);
  const [selectedWallet, setSelectedWallet] = useState<WalletType | "all">("all");
  const [globalSearch, setGlobalSearch] = useState("");
  const [isAiModalOpen, setIsAiModalOpen] = useState(false);

  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(() => {
    return localStorage.getItem("expenseos_auth") === "true";
  });
  const [user, setUser] = useState<UserProfile>(INITIAL_USER);

  const [expenses, setExpenses] = useState<Expense[]>(() => {
    const saved = localStorage.getItem("expenseos_expenses");
    return saved ? JSON.parse(saved) : INITIAL_EXPENSES;
  });

  const [incomeList, setIncomeList] = useState<IncomeItem[]>(() => {
    const saved = localStorage.getItem("expenseos_income");
    return saved ? JSON.parse(saved) : INITIAL_INCOME;
  });

  const [budgets, setBudgets] = useState<CategoryBudget[]>(() => {
    const saved = localStorage.getItem("expenseos_budgets");
    return saved ? JSON.parse(saved) : INITIAL_CATEGORY_BUDGETS;
  });

  const [goals, setGoals] = useState<FinancialGoal[]>(() => {
    const saved = localStorage.getItem("expenseos_goals");
    return saved ? JSON.parse(saved) : INITIAL_GOALS;
  });

  const [subscriptions, setSubscriptions] = useState<Subscription[]>(() => {
    const saved = localStorage.getItem("expenseos_subs");
    return saved ? JSON.parse(saved) : INITIAL_SUBSCRIPTIONS;
  });

  const [bills, setBills] = useState<Bill[]>(() => {
    const saved = localStorage.getItem("expenseos_bills");
    return saved ? JSON.parse(saved) : INITIAL_BILLS;
  });

  const [achievements, setAchievements] = useState<AchievementBadge[]>(INITIAL_ACHIEVEMENTS);
  const [challenges, setChallenges] = useState<SavingsChallenge[]>(INITIAL_CHALLENGES);
  const [notifications, setNotifications] = useState<AppNotification[]>(INITIAL_NOTIFICATIONS);
  const [logs, setLogs] = useState<ActivityLog[]>(INITIAL_LOGS);

  // Sync state to local storage
  useEffect(() => {
    localStorage.setItem("expenseos_theme", theme);
    if (theme === "dark") {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [theme]);

  useEffect(() => {
    localStorage.setItem("expenseos_expenses", JSON.stringify(expenses));
  }, [expenses]);

  useEffect(() => {
    localStorage.setItem("expenseos_income", JSON.stringify(incomeList));
  }, [incomeList]);

  useEffect(() => {
    localStorage.setItem("expenseos_budgets", JSON.stringify(budgets));
  }, [budgets]);

  useEffect(() => {
    localStorage.setItem("expenseos_goals", JSON.stringify(goals));
  }, [goals]);

  useEffect(() => {
    localStorage.setItem("expenseos_subs", JSON.stringify(subscriptions));
  }, [subscriptions]);

  useEffect(() => {
    localStorage.setItem("expenseos_bills", JSON.stringify(bills));
  }, [bills]);

  const toggleTheme = () => {
    setTheme((prev) => (prev === "dark" ? "light" : "dark"));
  };

  const formatCurrency = (amount: number): string => {
    const curr = CURRENCIES[selectedCurrency] || CURRENCIES.INR;
    const converted = amount * curr.rate;
    return new Intl.NumberFormat(curr.code === "INR" ? "en-IN" : "en-US", {
      style: "currency",
      currency: curr.code,
      maximumFractionDigits: 2,
    }).format(converted);
  };

  const login = (email: string, pass: string): boolean => {
    setIsLoggedIn(true);
    localStorage.setItem("expenseos_auth", "true");
    addLog("Authentication Login", `User ${email} signed in via JWT session`, "auth");
    addNotification("Welcome back!", "ExpenseOS AI loaded your personalized financial workspace.", "success");
    return true;
  };

  const logout = () => {
    setIsLoggedIn(false);
    localStorage.removeItem("expenseos_auth");
    setActiveTab("landing");
    addLog("Authentication Logout", "User logged out securely", "auth");
  };

  const updateUserProfile = (updated: Partial<UserProfile>) => {
    setUser((prev) => ({ ...prev, ...updated }));
  };

  const addNotification = (title: string, message: string, type: "alert" | "info" | "success" | "warning") => {
    const newNotif: AppNotification = {
      id: "notif-" + Date.now(),
      title,
      message,
      type,
      timestamp: "Just now",
      isRead: false,
    };
    setNotifications((prev) => [newNotif, ...prev]);
  };

  const addLog = (action: string, detail: string, type: ActivityLog["type"]) => {
    const newLog: ActivityLog = {
      id: "log-" + Date.now(),
      action,
      detail,
      timestamp: new Date().toLocaleString(),
      ipAddress: "127.0.0.1",
      device: "Desktop Workstation",
      type,
    };
    setLogs((prev) => [newLog, ...prev]);
  };

  // Expense operations
  const addExpense = (expData: Omit<Expense, "id">) => {
    const newExp: Expense = {
      ...expData,
      id: "exp-" + Date.now(),
    };
    setExpenses((prev) => [newExp, ...prev]);

    // Update Category budget spent
    setBudgets((prev) =>
      prev.map((b) =>
        b.category === expData.category ? { ...b, spent: b.spent + expData.amount } : b
      )
    );

    addLog("Transaction Added", `Spent ${formatCurrency(expData.amount)} at ${expData.merchantName}`, "transaction");
    addNotification("New Expense Logged", `${expData.title} (${formatCurrency(expData.amount)}) added to ${expData.category}.`, "info");

    // Add XP
    setUser((prev) => ({ ...prev, xpPoints: prev.xpPoints + 25 }));
  };

  const addBulkExpenses = (expList: Omit<Expense, "id">[]) => {
    if (expList.length === 0) return;

    const newExps: Expense[] = expList.map((expData, idx) => ({
      ...expData,
      id: "exp-bulk-" + Date.now() + "-" + idx,
    }));

    setExpenses((prev) => [...newExps, ...prev]);

    // Update Category budgets for all items
    setBudgets((prev) => {
      const budgetMap = { ...prev.reduce((acc, b) => ({ ...acc, [b.category]: b.spent }), {} as Record<string, number>) };
      for (const item of expList) {
        budgetMap[item.category] = (budgetMap[item.category] || 0) + item.amount;
      }
      return prev.map((b) => ({
        ...b,
        spent: budgetMap[b.category] !== undefined ? budgetMap[b.category] : b.spent,
      }));
    });

    const totalAmt = expList.reduce((sum, item) => sum + item.amount, 0);
    const dateStr = expList[0]?.date || "today";

    addLog(
      "Daily Batch Expenses Added",
      `Logged ${expList.length} expenses for ${dateStr} totaling ${formatCurrency(totalAmt)}`,
      "transaction"
    );
    addNotification(
      "Daily Batch Saved!",
      `Logged ${expList.length} expenses for ${dateStr} totaling ${formatCurrency(totalAmt)}.`,
      "success"
    );

    setUser((prev) => ({ ...prev, xpPoints: prev.xpPoints + (25 * expList.length) }));
  };

  const editExpense = (id: string, updated: Partial<Expense>) => {
    setExpenses((prev) => prev.map((e) => (e.id === id ? { ...e, ...updated } : e)));
    addLog("Transaction Modified", `Updated expense #${id}`, "transaction");
  };

  const deleteExpense = (id: string) => {
    const target = expenses.find((e) => e.id === id);
    if (target) {
      setExpenses((prev) => prev.filter((e) => e.id !== id));
      // Adjust budget
      setBudgets((prev) =>
        prev.map((b) =>
          b.category === target.category ? { ...b, spent: Math.max(0, b.spent - target.amount) } : b
        )
      );
      addLog("Transaction Deleted", `Removed expense ${target.title}`, "transaction");
    }
  };

  const duplicateExpense = (id: string) => {
    const target = expenses.find((e) => e.id === id);
    if (target) {
      addExpense({
        ...target,
        title: `${target.title} (Copy)`,
        date: new Date().toISOString().split("T")[0],
      });
    }
  };

  const bulkDeleteExpenses = (ids: string[]) => {
    setExpenses((prev) => prev.filter((e) => !ids.includes(e.id)));
    addLog("Bulk Transaction Delete", `Removed ${ids.length} transactions`, "transaction");
  };

  // Income operations
  const addIncome = (incData: Omit<IncomeItem, "id">) => {
    const newInc: IncomeItem = {
      ...incData,
      id: "inc-" + Date.now(),
    };
    setIncomeList((prev) => [newInc, ...prev]);
    addLog("Income Recorded", `Added income from ${incData.source} (${formatCurrency(incData.amount)})`, "transaction");
    addNotification("Income Received", `+${formatCurrency(incData.amount)} credited from ${incData.source}.`, "success");
  };

  const editIncome = (id: string, updated: Partial<IncomeItem>) => {
    setIncomeList((prev) => prev.map((i) => (i.id === id ? { ...i, ...updated } : i)));
    addLog("Income Updated", `Updated income item #${id}`, "transaction");
  };

  const deleteIncome = (id: string) => {
    setIncomeList((prev) => prev.filter((i) => i.id !== id));
  };

  const updateSalary = (newAmount: number) => {
    const existingSalary = incomeList.find((i) => i.category === "Salary" || i.source.toLowerCase().includes("salary"));
    if (existingSalary) {
      editIncome(existingSalary.id, { amount: newAmount });
    } else {
      addIncome({
        source: "Monthly Base Salary",
        category: "Salary",
        amount: newAmount,
        date: new Date().toISOString().split("T")[0],
        isRecurring: true,
        frequency: "monthly",
        wallet: "personal",
      });
    }
    addLog("Salary Updated", `Monthly base salary updated to ${formatCurrency(newAmount)}`, "transaction");
    addNotification("Salary Updated", `Monthly base salary set to ${formatCurrency(newAmount)}.`, "success");
  };

  // Budget operation
  const updateBudget = (category: string, newLimit: number) => {
    setBudgets((prev) =>
      prev.map((b) => (b.category === category ? { ...b, limit: newLimit } : b))
    );
    addLog("Budget Re-configured", `Set ${category} limit to ${formatCurrency(newLimit)}`, "transaction");
  };

  // Goals operations
  const addGoal = (goalData: Omit<FinancialGoal, "id" | "currentAmount">) => {
    const newGoal: FinancialGoal = {
      ...goalData,
      id: "goal-" + Date.now(),
      currentAmount: 0,
    };
    setGoals((prev) => [...prev, newGoal]);
    addLog("Goal Created", `New savings goal "${goalData.title}" targeted for ${formatCurrency(goalData.targetAmount)}`, "transaction");
  };

  const addGoalContribution = (goalId: string, amount: number) => {
    setGoals((prev) =>
      prev.map((g) => {
        if (g.id === goalId) {
          const updatedAmount = g.currentAmount + amount;
          if (updatedAmount >= g.targetAmount && g.currentAmount < g.targetAmount) {
            confetti({ particleCount: 120, spread: 70, origin: { y: 0.6 } });
            addNotification("🎉 Goal Achieved!", `Congratulations! You reached your goal "${g.title}"!`, "success");
          }
          return { ...g, currentAmount: updatedAmount };
        }
        return g;
      })
    );
    addLog("Goal Contribution", `Added ${formatCurrency(amount)} to goal`, "transaction");
  };

  const deleteGoal = (id: string) => {
    setGoals((prev) => prev.filter((g) => g.id !== id));
  };

  // Subscriptions & Bills
  const addSubscription = (subData: Omit<Subscription, "id">) => {
    const newSub: Subscription = {
      ...subData,
      id: "sub-" + Date.now(),
    };
    setSubscriptions((prev) => [...prev, newSub]);
  };

  const deleteSubscription = (id: string) => {
    setSubscriptions((prev) => prev.filter((s) => s.id !== id));
  };

  const toggleBillPaid = (id: string) => {
    setBills((prev) =>
      prev.map((b) => {
        if (b.id === id) {
          const newStatus = !b.isPaid;
          if (newStatus) {
            addExpense({
              title: `Bill Paid: ${b.title}`,
              amount: b.amount,
              category: "Bills & Utilities",
              date: new Date().toISOString().split("T")[0],
              paymentMethod: "Bank Transfer",
              merchantName: b.billerName,
              priority: "High",
              tags: ["Bill", "Utility"],
              wallet: "personal",
              currency: "USD",
            });
          }
          return { ...b, isPaid: newStatus };
        }
        return b;
      })
    );
  };

  const addBill = (billData: Omit<Bill, "id" | "isPaid">) => {
    const newBill: Bill = {
      ...billData,
      id: "bill-" + Date.now(),
      isPaid: false,
    };
    setBills((prev) => [...prev, newBill]);
  };

  const markNotificationRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isRead: true } : n))
    );
  };

  const clearAllNotifications = () => {
    setNotifications([]);
  };

  // Filtered dataset according to selected wallet
  const filteredExpenses = expenses.filter((e) =>
    selectedWallet === "all" ? true : e.wallet === selectedWallet
  );
  const filteredIncome = incomeList.filter((i) =>
    selectedWallet === "all" ? true : i.wallet === selectedWallet
  );

  // Compute live financial metrics
  const totalIncomeVal = filteredIncome.reduce((s, x) => s + x.amount, 0);
  const totalExpenseVal = filteredExpenses.reduce((s, x) => s + x.amount, 0);
  const monthlySavings = Math.max(0, totalIncomeVal - totalExpenseVal);
  const savingsRate = totalIncomeVal > 0 ? Math.round((monthlySavings / totalIncomeVal) * 100) : 0;
  
  const totalInvestments = filteredExpenses
    .filter((e) => e.category === "Investment")
    .reduce((s, x) => s + x.amount, 0) + 18500; // base investment capital

  const emergencyFundAmount = goals
    .filter((g) => g.category === "Emergency Fund")
    .reduce((s, x) => s + x.currentAmount, 0);

  const totalBudgetLimit = budgets.reduce((s, b) => s + b.limit, 0);
  const totalBudgetSpent = budgets.reduce((s, b) => s + b.spent, 0);
  const budgetRemaining = Math.max(0, totalBudgetLimit - totalBudgetSpent);

  const metrics = {
    totalBalance: 24890.50 + totalIncomeVal - totalExpenseVal,
    monthlyIncome: totalIncomeVal,
    monthlyExpense: totalExpenseVal,
    monthlySavings,
    savingsRate,
    netWorth: 142500.00 + (totalIncomeVal - totalExpenseVal) + totalInvestments,
    creditScore: 785,
    financialHealthScore: Math.min(100, Math.max(40, 60 + savingsRate - (totalBudgetSpent > totalBudgetLimit ? 15 : 0))),
    budgetRemaining,
    totalInvestments,
    emergencyFundAmount,
    monthlyCashFlow: totalIncomeVal - totalExpenseVal,
  };

  return (
    <ExpenseContext.Provider
      value={{
        activeTab,
        setActiveTab,
        theme,
        toggleTheme,
        selectedCurrency,
        setSelectedCurrency,
        selectedWallet,
        setSelectedWallet,
        formatCurrency,
        isLoggedIn,
        login,
        logout,
        user,
        updateUserProfile,
        expenses: filteredExpenses,
        incomeList: filteredIncome,
        budgets,
        goals,
        subscriptions,
        bills,
        achievements,
        challenges,
        notifications,
        logs,
        addExpense,
        addBulkExpenses,
        editExpense,
        deleteExpense,
        duplicateExpense,
        bulkDeleteExpenses,
        addIncome,
        editIncome,
        deleteIncome,
        updateSalary,
        updateBudget,
        addGoal,
        addGoalContribution,
        deleteGoal,
        addSubscription,
        deleteSubscription,
        toggleBillPaid,
        addBill,
        markNotificationRead,
        clearAllNotifications,
        addNotification,
        addLog,
        metrics,
        globalSearch,
        setGlobalSearch,
        isAiModalOpen,
        setIsAiModalOpen,
      }}
    >
      {children}
    </ExpenseContext.Provider>
  );
};

export const useExpenseOS = () => {
  const context = useContext(ExpenseContext);
  if (!context) {
    throw new Error("useExpenseOS must be used within an ExpenseProvider");
  }
  return context;
};
