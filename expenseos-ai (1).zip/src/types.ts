export type CurrencyCode = "USD" | "EUR" | "GBP" | "INR" | "JPY" | "CAD" | "AUD";

export interface CurrencyConfig {
  code: CurrencyCode;
  symbol: string;
  rate: number; // Conversion rate relative to USD
  name: string;
}

export type WalletType = "personal" | "family" | "business";

export type CategoryType =
  | "Groceries"
  | "Dining & Food"
  | "Shopping"
  | "Entertainment"
  | "Bills & Utilities"
  | "Housing & Rent"
  | "Transport & Fuel"
  | "Healthcare"
  | "Investment"
  | "Subscriptions"
  | "Travel & Vacation"
  | "Education"
  | "Income"
  | "Electronics"
  | "Other";

export type PaymentMethod =
  | "Credit Card"
  | "Debit Card"
  | "Bank Transfer"
  | "UPI"
  | "Apple Pay"
  | "Cash"
  | "Crypto";

export type ExpensePriority = "Low" | "Medium" | "High";

export interface ReceiptItem {
  name: string;
  price: number;
  quantity: number;
}

export interface Expense {
  id: string;
  title: string;
  amount: number;
  category: CategoryType;
  date: string; // YYYY-MM-DD
  paymentMethod: PaymentMethod;
  merchantName: string;
  priority: ExpensePriority;
  tags: string[];
  notes?: string;
  receiptUrl?: string;
  receiptItems?: ReceiptItem[];
  location?: string;
  isRecurring?: boolean;
  recurringFrequency?: "weekly" | "monthly" | "yearly";
  isInstallment?: boolean;
  installmentInfo?: { current: number; total: number; monthlyAmount: number };
  wallet: WalletType;
  mood?: "Calm" | "Impulsive" | "Anxious" | "Excited" | "Stressed";
  isFavorite?: boolean;
  currency: CurrencyCode;
}

export interface IncomeItem {
  id: string;
  source: string;
  category: "Salary" | "Freelance" | "Business" | "Rental" | "Interest" | "Dividend" | "Bonus" | "Gift" | "Crypto" | "Others";
  amount: number;
  date: string;
  isRecurring: boolean;
  frequency?: "monthly" | "weekly" | "one-time";
  wallet: WalletType;
  notes?: string;
}

export interface CategoryBudget {
  category: CategoryType;
  limit: number;
  spent: number;
  color: string;
}

export interface FinancialGoal {
  id: string;
  title: string;
  category: "Vacation" | "Car" | "Bike" | "Laptop" | "House" | "Wedding" | "Emergency Fund" | "Retirement" | "Education" | "Investment";
  targetAmount: number;
  currentAmount: number;
  targetDate: string;
  color: string;
  iconName: string;
  wallet: WalletType;
}

export interface Subscription {
  id: string;
  name: string;
  category: string;
  monthlyCost: number;
  billingCycle: "monthly" | "yearly";
  nextBillingDate: string;
  status: "active" | "flagged_unused" | "cancelled";
  logoUrl?: string;
  usageScore: number; // 0-100
  aiSuggestion?: string;
}

export interface Bill {
  id: string;
  title: string;
  category: "Electricity" | "Internet" | "Rent" | "Insurance" | "Loan EMI" | "Credit Card" | "Water" | "Gas" | "Phone";
  amount: number;
  dueDate: string;
  isPaid: boolean;
  autoPay: boolean;
  billerName: string;
}

export interface AchievementBadge {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlockedAt?: string;
  isUnlocked: boolean;
  progress: number; // 0-100
  xpReward: number;
}

export interface SavingsChallenge {
  id: string;
  title: string;
  description: string;
  targetAmount: number;
  currentProgress: number;
  durationDays: number;
  daysRemaining: number;
  isCompleted: boolean;
  rewardXp: number;
}

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  type: "alert" | "info" | "success" | "warning";
  timestamp: string;
  isRead: boolean;
  linkTab?: string;
}

export interface ActivityLog {
  id: string;
  action: string;
  detail: string;
  timestamp: string;
  ipAddress: string;
  device: string;
  type: "auth" | "transaction" | "security" | "ai" | "export";
}

export interface UserProfile {
  name: string;
  email: string;
  avatar: string;
  role: "User" | "Admin" | "PRO CFO";
  tier: "Free" | "Pro" | "Enterprise";
  xpPoints: number;
  level: number;
  streakDays: number;
  twoFactorEnabled: boolean;
  biometricEnabled: boolean;
  pinLockEnabled: boolean;
  pinCode?: string;
}
