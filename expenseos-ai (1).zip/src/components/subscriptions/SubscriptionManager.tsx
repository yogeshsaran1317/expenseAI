import React from "react";
import { useExpenseOS } from "../../context/ExpenseContext";
import { Repeat, AlertTriangle, Sparkles, Trash2, CheckCircle, ExternalLink } from "lucide-react";

export const SubscriptionManager: React.FC = () => {
  const { subscriptions, deleteSubscription, formatCurrency } = useExpenseOS();

  const totalMonthlySub = subscriptions.reduce((s, x) => s + x.monthlyCost, 0);
  const unusedSubs = subscriptions.filter((s) => s.status === "flagged_unused");

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
          <Repeat className="h-6 w-6 text-purple-500" />
          Subscription & Recurring Fee Sniper
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Unused subscription detection, usage scoring & automated cancellation advice
        </p>
      </div>

      {/* Summary Card */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-xl">
          <p className="text-[10px] font-bold uppercase text-slate-400">Total Monthly Recurring</p>
          <p className="text-2xl font-extrabold text-slate-900 dark:text-white mt-1">
            {formatCurrency(totalMonthlySub)}/mo
          </p>
          <p className="text-[10px] text-slate-400 mt-1">${(totalMonthlySub * 12).toFixed(2)} yearly commitment</p>
        </div>

        <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-xl">
          <p className="text-[10px] font-bold uppercase text-slate-400">Tracked Subscriptions</p>
          <p className="text-2xl font-extrabold text-indigo-600 dark:text-indigo-400 mt-1">
            {subscriptions.length} Active Services
          </p>
          <p className="text-[10px] text-slate-400 mt-1">SaaS, Streaming, Gym & Cloud</p>
        </div>

        <div className="rounded-3xl border border-amber-200 dark:border-amber-800/50 bg-amber-50 dark:bg-amber-950/40 p-5 shadow-xl">
          <p className="text-[10px] font-bold uppercase text-amber-700 dark:text-amber-400">Flagged Wasteful Subscriptions</p>
          <p className="text-2xl font-extrabold text-amber-600 dark:text-amber-400 mt-1">
            {unusedSubs.length} Low Utility
          </p>
          <p className="text-[10px] text-amber-700/80 dark:text-amber-300 mt-1">
            Potential yearly savings: ${unusedSubs.reduce((s, x) => s + x.monthlyCost * 12, 0).toFixed(2)}
          </p>
        </div>
      </div>

      {/* Subscriptions List */}
      <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xl overflow-hidden">
        <div className="p-4 border-b border-slate-100 dark:border-slate-800 font-bold text-xs text-slate-700 dark:text-slate-300">
          Recurring Subscriptions ({subscriptions.length})
        </div>

        <div className="divide-y divide-slate-100 dark:divide-slate-800/60">
          {subscriptions.map((sub) => (
            <div key={sub.id} className="p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:bg-slate-50 dark:hover:bg-slate-800/40 text-xs">
              <div className="flex items-center gap-3">
                <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-purple-500/10 text-purple-500 font-bold text-lg">
                  {sub.name.charAt(0)}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">{sub.name}</h3>
                    {sub.status === "flagged_unused" && (
                      <span className="rounded-full bg-rose-500/10 px-2 py-0.5 text-[9px] font-bold text-rose-500 flex items-center gap-1">
                        <AlertTriangle className="h-3 w-3" /> Unused Warning
                      </span>
                    )}
                  </div>
                  <p className="text-[10px] text-slate-400 mt-0.5">
                    {sub.category} • Next billing: {sub.nextBillingDate} • Usage Score: {sub.usageScore}/100
                  </p>
                  {sub.aiSuggestion && (
                    <p className="mt-1 text-[11px] text-amber-600 dark:text-amber-400 font-medium">
                      💡 AI Advice: {sub.aiSuggestion}
                    </p>
                  )}
                </div>
              </div>

              <div className="flex items-center justify-between md:justify-end gap-4 border-t md:border-t-0 border-slate-100 dark:border-slate-800 pt-3 md:pt-0">
                <span className="font-mono font-extrabold text-sm text-slate-900 dark:text-white">
                  {formatCurrency(sub.monthlyCost)}/mo
                </span>
                <button
                  onClick={() => deleteSubscription(sub.id)}
                  className="p-2 rounded-xl border border-rose-200 dark:border-rose-900/60 bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 hover:bg-rose-100 font-bold text-xs cursor-pointer flex items-center gap-1"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                  Cancel & Remove
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
