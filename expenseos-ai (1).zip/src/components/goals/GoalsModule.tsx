import React, { useState } from "react";
import { useExpenseOS } from "../../context/ExpenseContext";
import { Target, Plus, ShieldCheck, Car, Plane, Laptop, Trophy, Sparkles, CheckCircle } from "lucide-react";

export const GoalsModule: React.FC = () => {
  const { goals, addGoalContribution, addGoal, formatCurrency } = useExpenseOS();

  const [contribAmount, setContribAmount] = useState<{ [id: string]: string }>({});
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [goalTitle, setGoalTitle] = useState("");
  const [goalCategory, setGoalCategory] = useState<any>("Vacation");
  const [goalTarget, setGoalTarget] = useState("");
  const [goalDate, setGoalDate] = useState("2026-12-31");

  const handleContrib = (id: string) => {
    const val = parseFloat(contribAmount[id] || "0");
    if (val > 0) {
      addGoalContribution(id, val);
      setContribAmount({ ...contribAmount, [id]: "" });
    }
  };

  const handleCreateGoal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!goalTitle || !goalTarget) return;

    addGoal({
      title: goalTitle,
      category: goalCategory,
      targetAmount: parseFloat(goalTarget),
      targetDate: goalDate,
      color: "#6366f1",
      iconName: "Target",
      wallet: "personal",
    });

    setGoalTitle("");
    setGoalTarget("");
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
            <Target className="h-6 w-6 text-indigo-500" />
            Financial Goals & Wealth Accumulation
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Emergency reserves, vehicle funds, property, travel, and FIRE targets
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-bold text-xs shadow-md shadow-indigo-500/20 cursor-pointer"
        >
          <Plus className="h-4 w-4" />
          Create Wealth Goal
        </button>
      </div>

      {/* Goal Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {goals.map((goal) => {
          const percent = Math.min(100, Math.round((goal.currentAmount / goal.targetAmount) * 100));
          const isComplete = percent >= 100;

          return (
            <div
              key={goal.id}
              className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-xl flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-indigo-500/10 text-indigo-500 font-bold">
                      <Target className="h-5 w-5" />
                    </div>
                    <div>
                      <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">{goal.title}</h3>
                      <p className="text-[10px] text-slate-400">Target Date: {goal.targetDate}</p>
                    </div>
                  </div>

                  <span className={`rounded-full px-2.5 py-0.5 text-[10px] font-bold ${
                    isComplete ? "bg-emerald-500/10 text-emerald-500" : "bg-indigo-500/10 text-indigo-500"
                  }`}>
                    {percent}% Achieved
                  </span>
                </div>

                <div className="flex items-baseline justify-between text-xs mt-4">
                  <span className="text-slate-400">
                    Saved: <strong className="text-slate-900 dark:text-white">{formatCurrency(goal.currentAmount)}</strong>
                  </span>
                  <span className="text-slate-400">
                    Target: <strong className="text-slate-900 dark:text-white">{formatCurrency(goal.targetAmount)}</strong>
                  </span>
                </div>

                <div className="mt-2 w-full bg-slate-100 dark:bg-slate-800 rounded-full h-3 overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-cyan-400 via-indigo-500 to-purple-600 h-full rounded-full transition-all duration-300"
                    style={{ width: `${percent}%` }}
                  ></div>
                </div>
              </div>

              {/* Contribution Input */}
              <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center gap-2">
                <input
                  type="number"
                  placeholder="Deposit ($)"
                  value={contribAmount[goal.id] || ""}
                  onChange={(e) => setContribAmount({ ...contribAmount, [goal.id]: e.target.value })}
                  className="flex-1 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs font-bold text-slate-900 dark:text-white"
                />
                <button
                  onClick={() => handleContrib(goal.id)}
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs cursor-pointer shadow-md shadow-indigo-500/20"
                >
                  Deposit Capital
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Goal Creation Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md p-4">
          <div className="w-full max-w-md rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">Create New Wealth Goal</h3>
            <form onSubmit={handleCreateGoal} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">Goal Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Kyoto Autumn Vacation Fund"
                  value={goalTitle}
                  onChange={(e) => setGoalTitle(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-slate-900 dark:text-white focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Target Amount ($)</label>
                <input
                  type="number"
                  required
                  placeholder="5000"
                  value={goalTarget}
                  onChange={(e) => setGoalTarget(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-3 py-2 font-bold text-slate-900 dark:text-white focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Target Completion Date</label>
                <input
                  type="date"
                  required
                  value={goalDate}
                  onChange={(e) => setGoalDate(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-slate-900 dark:text-white focus:outline-none"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 rounded-xl border border-slate-200 dark:border-slate-800 py-2 font-bold text-slate-500"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 rounded-xl bg-indigo-600 py-2 font-bold text-white shadow-md shadow-indigo-500/20"
                >
                  Save Goal
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
