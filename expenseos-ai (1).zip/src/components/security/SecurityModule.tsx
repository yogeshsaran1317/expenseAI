import React, { useState } from "react";
import { ShieldCheck, Lock, Fingerprint, Key, RefreshCw, CheckCircle2 } from "lucide-react";

export const SecurityModule: React.FC = () => {
  const [pin, setPin] = useState(["", "", "", ""]);
  const [isPinSet, setIsPinSet] = useState(true);

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
          <ShieldCheck className="h-6 w-6 text-emerald-500" />
          Bank-Grade Security & Encryption Audit
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          AES-256 local vault encryption, biometric FaceID hardware keys & PIN protection
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-5 rounded-3xl border border-emerald-200 dark:border-emerald-800/50 bg-emerald-50/50 dark:bg-emerald-950/30 shadow-xl space-y-2">
          <ShieldCheck className="h-6 w-6 text-emerald-500" />
          <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">AES-256 Vault Encryption</h3>
          <p className="text-xs text-slate-600 dark:text-slate-300">All local storage financial records encrypted with client-side zero-knowledge keys.</p>
        </div>

        <div className="p-5 rounded-3xl border border-indigo-200 dark:border-indigo-800/50 bg-indigo-50/50 dark:bg-indigo-950/30 shadow-xl space-y-2">
          <Fingerprint className="h-6 w-6 text-indigo-500" />
          <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">Biometric Passkey Authentication</h3>
          <p className="text-xs text-slate-600 dark:text-slate-300">Apple TouchID / FaceID & WebAuthn standard integrated for instant secure login.</p>
        </div>

        <div className="p-5 rounded-3xl border border-purple-200 dark:border-purple-800/50 bg-purple-50/50 dark:bg-purple-950/30 shadow-xl space-y-2">
          <Lock className="h-6 w-6 text-purple-500" />
          <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">4-Digit PIN Vault Lock</h3>
          <p className="text-xs text-slate-600 dark:text-slate-300">Automatic screen lock after 2 minutes of inactive session time.</p>
        </div>
      </div>
    </div>
  );
};
