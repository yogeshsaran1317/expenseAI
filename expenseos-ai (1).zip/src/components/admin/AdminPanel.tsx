import React from "react";
import { useExpenseOS } from "../../context/ExpenseContext";
import { Database, Server, Download, RotateCcw, Activity, ShieldAlert, CheckCircle2 } from "lucide-react";

export const AdminPanel: React.FC = () => {
  const { expenses, incomeList, resetAllData, addNotification } = useExpenseOS();

  const handleExportJSON = () => {
    const backup = {
      expenses,
      incomeList,
      timestamp: new Date().toISOString(),
    };
    const blob = new Blob([JSON.stringify(backup, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `ExpenseOS_FullBackup_${new Date().toISOString().split("T")[0]}.json`;
    a.click();
    addNotification("Backup Downloaded", "Full database state exported as JSON file", "success");
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
          <Server className="h-6 w-6 text-indigo-500" />
          Admin & System Control Console
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Database health monitoring, full JSON state export & system reset tools
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="p-6 rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xl space-y-4">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Database className="h-4 w-4 text-cyan-500" />
            Database Backup & Sync
          </h3>
          <p className="text-xs text-slate-500">
            Export a full machine-readable JSON archive containing all financial records, budgets, and goals.
          </p>
          <button
            onClick={handleExportJSON}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-md shadow-indigo-500/20 cursor-pointer"
          >
            <Download className="h-4 w-4" />
            Download Full Database JSON
          </button>
        </div>

        <div className="p-6 rounded-3xl border border-rose-200 dark:border-rose-900/50 bg-rose-50/50 dark:bg-rose-950/20 shadow-xl space-y-4">
          <h3 className="text-sm font-bold text-rose-700 dark:text-rose-400 flex items-center gap-2">
            <ShieldAlert className="h-4 w-4 text-rose-500" />
            Factory Reset Data State
          </h3>
          <p className="text-xs text-slate-600 dark:text-slate-400">
            Reset all modified local state back to initial mock database values.
          </p>
          <button
            onClick={resetAllData}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-md shadow-rose-500/20 cursor-pointer"
          >
            <RotateCcw className="h-4 w-4" />
            Reset to Default State
          </button>
        </div>
      </div>
    </div>
  );
};
