import React, { useState } from "react";
import { useExpenseOS } from "../../context/ExpenseContext";
import { TrendingUp, Plus, Trash2, Check, Edit2, Wallet, DollarSign } from "lucide-react";
import { CURRENCIES } from "../../data/mockData";

export const IncomeModule: React.FC = () => {
  const { incomeList, addIncome, editIncome, deleteIncome, updateSalary, formatCurrency, selectedCurrency } = useExpenseOS();
  const currSymbol = CURRENCIES[selectedCurrency]?.symbol || "₹";

  // Find existing main salary item if present
  const salaryItem = incomeList.find((i) => i.category === "Salary" || i.source.toLowerCase().includes("salary"));
  const currentSalaryAmount = salaryItem ? salaryItem.amount : 0;

  const [salaryInput, setSalaryInput] = useState<string>(currentSalaryAmount ? currentSalaryAmount.toString() : "");
  const [isUpdatingSalary, setIsUpdatingSalary] = useState(false);

  // Additional income modal state
  const [source, setSource] = useState("");
  const [amount, setAmount] = useState("");
  const [category, setCategory] = useState<any>("Salary");
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [wallet, setWallet] = useState<any>("personal");
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Edit item modal state
  const [editingId, setEditingId] = useState<string | null>(null);

  const totalIncome = incomeList.reduce((s, i) => s + i.amount, 0);

  const handleSalarySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(salaryInput);
    if (!isNaN(val) && val >= 0) {
      updateSalary(val);
      setIsUpdatingSalary(false);
    }
  };

  const handleAddIncomeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!source || !amount) return;

    if (editingId) {
      editIncome(editingId, {
        source,
        category,
        amount: parseFloat(amount),
        date,
        wallet,
      });
      setEditingId(null);
    } else {
      addIncome({
        source,
        category,
        amount: parseFloat(amount),
        date,
        isRecurring: true,
        frequency: "monthly",
        wallet,
      });
    }

    setSource("");
    setAmount("");
    setIsModalOpen(false);
  };

  const openEditModal = (inc: any) => {
    setEditingId(inc.id);
    setSource(inc.source);
    setAmount(inc.amount.toString());
    setCategory(inc.category);
    setDate(inc.date);
    setWallet(inc.wallet || "personal");
    setIsModalOpen(true);
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      {/* Header Section */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-light text-white tracking-tight">
            Monthly <span className="font-bold">Salary & Income</span>
          </h1>
          <p className="text-xs sm:text-sm text-neutral-400 mt-1">
            Update your monthly base salary and manage recurring revenue sources
          </p>
        </div>

        <button
          onClick={() => {
            setEditingId(null);
            setSource("");
            setAmount("");
            setIsModalOpen(true);
          }}
          className="flex items-center gap-2 px-5 py-2.5 bg-white text-black font-semibold text-xs rounded-xl hover:bg-neutral-200 transition-colors shadow-lg cursor-pointer"
        >
          <Plus className="h-4 w-4" />
          Add Additional Income
        </button>
      </div>

      {/* Main Base Salary Card */}
      <div className="bg-gradient-to-r from-emerald-950/60 via-neutral-900 to-neutral-950 border border-emerald-500/30 rounded-3xl p-6 sm:p-8 backdrop-blur-xl relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono font-bold uppercase tracking-widest text-emerald-400">
              <TrendingUp className="h-4 w-4 text-emerald-400" />
              Monthly Base Salary
            </div>
            <p className="text-3xl sm:text-4xl font-extrabold text-white mt-2 font-mono tracking-tight">
              {formatCurrency(currentSalaryAmount)}
            </p>
            <p className="text-xs text-neutral-400 mt-1">
              Total Calculated Monthly Income: <span className="text-emerald-400 font-bold font-mono">{formatCurrency(totalIncome)}</span>
            </p>
          </div>

          {/* Inline Salary Quick Form */}
          <div className="bg-white/5 border border-white/10 p-4 rounded-2xl backdrop-blur-md max-w-md w-full">
            <p className="text-xs font-bold text-white mb-2">Update Monthly Base Salary</p>
            <form onSubmit={handleSalarySubmit} className="flex gap-2">
              <div className="relative flex-1">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500 font-mono text-xs">{currSymbol}</span>
                <input
                  type="number"
                  step="0.01"
                  required
                  placeholder="Enter new salary amount..."
                  value={salaryInput}
                  onChange={(e) => setSalaryInput(e.target.value)}
                  className="w-full bg-neutral-950 border border-white/15 rounded-xl pl-7 pr-3 py-2 text-xs text-white font-mono font-bold focus:border-emerald-500 focus:outline-none"
                />
              </div>
              <button
                type="submit"
                className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-black font-bold text-xs rounded-xl transition-all cursor-pointer flex items-center gap-1.5 shrink-0"
              >
                <Check className="h-4 w-4" />
                Update Salary
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* Income Streams List */}
      <div className="bg-neutral-950/60 border border-white/10 rounded-3xl p-6 backdrop-blur-xl shadow-xl">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h3 className="text-base font-bold text-white">All Income Inflows</h3>
            <p className="text-xs text-neutral-500 font-mono">
              Auto-calculated into your monthly cash balance ({incomeList.length} sources)
            </p>
          </div>
        </div>

        <div className="space-y-3">
          {incomeList.length === 0 ? (
            <div className="p-8 text-center text-neutral-500 text-xs">
              No income entries registered yet. Use the form above to update your monthly salary.
            </div>
          ) : (
            incomeList.map((inc) => (
              <div
                key={inc.id}
                className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5 hover:border-white/10 transition-all text-xs"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 font-bold">
                    <DollarSign className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="font-bold text-white text-sm">{inc.source}</p>
                    <p className="text-[10px] font-mono text-neutral-400 mt-0.5">
                      {inc.category} • {inc.date} • {inc.wallet || "Personal"} Wallet
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <span className="font-mono font-extrabold text-emerald-400 text-base">
                    +{formatCurrency(inc.amount)}
                  </span>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => openEditModal(inc)}
                      className="p-2 rounded-lg text-neutral-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
                      title="Edit Income"
                    >
                      <Edit2 className="h-3.5 w-3.5" />
                    </button>
                    <button
                      onClick={() => deleteIncome(inc.id)}
                      className="p-2 rounded-lg text-neutral-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors cursor-pointer"
                      title="Delete Income"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Add / Edit Income Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <div className="w-full max-w-md rounded-3xl border border-white/10 bg-neutral-950 p-6 shadow-2xl space-y-4">
            <h3 className="text-lg font-bold text-white">
              {editingId ? "Edit Income Entry" : "Record Additional Income"}
            </h3>

            <form onSubmit={handleAddIncomeSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-neutral-400 font-mono text-[10px] uppercase tracking-wider mb-1">
                  Income Source Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Monthly Base Salary, Freelance Bonus"
                  value={source}
                  onChange={(e) => setSource(e.target.value)}
                  className="w-full rounded-xl border border-white/10 bg-white/5 px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-neutral-400 font-mono text-[10px] uppercase tracking-wider mb-1">
                  Amount ({currSymbol})
                </label>
                <input
                  type="number"
                  step="0.01"
                  required
                  placeholder="5000.00"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full rounded-xl border border-white/10 bg-white/5 px-3 py-2.5 text-white font-mono font-bold focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-neutral-400 font-mono text-[10px] uppercase tracking-wider mb-1">
                    Category
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full rounded-xl border border-white/10 bg-neutral-900 px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500"
                  >
                    <option value="Salary">Salary</option>
                    <option value="Freelance">Freelance</option>
                    <option value="Business">Business</option>
                    <option value="Dividend">Dividend</option>
                    <option value="Bonus">Bonus</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block text-neutral-400 font-mono text-[10px] uppercase tracking-wider mb-1">
                    Wallet
                  </label>
                  <select
                    value={wallet}
                    onChange={(e) => setWallet(e.target.value)}
                    className="w-full rounded-xl border border-white/10 bg-neutral-900 px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500"
                  >
                    <option value="personal">Personal</option>
                    <option value="family">Family</option>
                    <option value="business">Business</option>
                  </select>
                </div>
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 rounded-xl border border-white/10 py-2.5 font-bold text-neutral-400 hover:bg-white/5 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 rounded-xl bg-emerald-500 hover:bg-emerald-400 font-bold text-black py-2.5 transition-colors cursor-pointer"
                >
                  {editingId ? "Save Changes" : "Add Income"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
