import React, { useState } from "react";
import { useExpenseOS } from "../../context/ExpenseContext";
import { PieChart, Sliders, AlertTriangle, Sparkles, CheckCircle2 } from "lucide-react";

export const BudgetModule: React.FC = () => {
  const { budgets, updateBudget, formatCurrency } = useExpenseOS();

  const [editingCategory, setEditingCategory] = useState<string | null>(null);
  const [newLimit, setNewLimit] = useState("");

  const handleSaveBudget = (cat: string) => {
    const val = parseFloat(newLimit);
    if (!isNaN(val) && val > 0) {
      updateBudget(cat, val);
    }
    setEditingCategory(null);
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
          <PieChart className="h-6 w-6 text-indigo-500" />
          Smart Category Budget Radar
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Dynamic spending caps, category limits & AI over-budget warnings
        </p>
      </div>

      {/* AI Smart Suggestion Banner */}
      <div className="p-4 rounded-3xl bg-gradient-to-r from-indigo-950 via-purple-950 to-slate-900 border border-indigo-500/20 text-white flex items-center gap-3">
        <Sparkles className="h-6 w-6 text-cyan-400 flex-shrink-0 animate-pulse" />
        <div className="text-xs">
          <p className="font-bold text-cyan-300">AI Smart Budget Recommendation</p>
          <p className="text-slate-300 mt-0.5">
            Based on your July income, increasing your Investment allocation by {formatCurrency(2500)}/mo optimizes compound interest without affecting core dining or grocery needs.
          </p>
        </div>
      </div>

      {/* Category Budget Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {budgets.map((b) => {
          const percent = Math.min(100, Math.round((b.spent / b.limit) * 100));
          const isOver = b.spent > b.limit;
          const isWarn = percent >= 80;

          return (
            <div
              key={b.category}
              className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 shadow-xl flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="font-bold text-sm text-slate-900 dark:text-white">{b.category}</span>
                  {isOver ? (
                    <span className="rounded-full bg-rose-500/10 px-2.5 py-0.5 text-[10px] font-bold text-rose-500 flex items-center gap-1">
                      <AlertTriangle className="h-3 w-3" /> Over Budget
                    </span>
                  ) : isWarn ? (
                    <span className="rounded-full bg-amber-500/10 px-2.5 py-0.5 text-[10px] font-bold text-amber-500">
                      Near Limit
                    </span>
                  ) : (
                    <span className="rounded-full bg-emerald-500/10 px-2.5 py-0.5 text-[10px] font-bold text-emerald-500">
                      On Track
                    </span>
                  )}
                </div>

                <div className="flex items-baseline justify-between text-xs mt-3">
                  <span className="text-slate-400">Spent: <strong className="text-slate-900 dark:text-white">{formatCurrency(b.spent)}</strong></span>
                  <span className="text-slate-400">Limit: <strong className="text-slate-900 dark:text-white">{formatCurrency(b.limit)}</strong></span>
                </div>

                {/* Progress Bar */}
                <div className="mt-2 w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2.5 overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-300 ${
                      isOver ? "bg-rose-500" : isWarn ? "bg-amber-500" : "bg-emerald-500"
                    }`}
                    style={{ width: `${percent}%` }}
                  ></div>
                </div>
              </div>

              {/* Edit Limit Section */}
              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/60 flex items-center justify-between text-xs">
                {editingCategory === b.category ? (
                  <div className="flex items-center gap-2 w-full">
                    <input
                      type="number"
                      value={newLimit}
                      onChange={(e) => setNewLimit(e.target.value)}
                      placeholder={String(b.limit)}
                      className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-2 py-1 text-xs text-slate-900 dark:text-white"
                    />
                    <button
                      onClick={() => handleSaveBudget(b.category)}
                      className="px-2.5 py-1 rounded-lg bg-indigo-600 text-white font-bold"
                    >
                      Save
                    </button>
                  </div>
                ) : (
                  <>
                    <span className="text-slate-400 text-[11px]">{percent}% utilized</span>
                    <button
                      onClick={() => {
                        setEditingCategory(b.category);
                        setNewLimit(String(b.limit));
                      }}
                      className="text-indigo-500 font-bold hover:underline cursor-pointer flex items-center gap-1"
                    >
                      <Sliders className="h-3 w-3" /> Re-cap
                    </button>
                  </>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
