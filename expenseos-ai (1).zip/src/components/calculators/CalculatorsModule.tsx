import React, { useState } from "react";
import { useExpenseOS } from "../../context/ExpenseContext";
import { Calculator, TrendingUp, Building2, Flame, ShieldAlert, ArrowRightLeft } from "lucide-react";

export const CalculatorsModule: React.FC = () => {
  const { formatCurrency, selectedCurrency, setCurrency } = useExpenseOS();

  const [activeCalc, setActiveCalc] = useState<"sip" | "emi" | "fire" | "emergency" | "fx">("sip");

  // SIP Calculator State
  const [sipMonthly, setSipMonthly] = useState("500");
  const [sipRate, setSipRate] = useState("12");
  const [sipYears, setSipYears] = useState("10");

  const sipM = parseFloat(sipMonthly) || 0;
  const sipR = (parseFloat(sipRate) || 0) / 12 / 100;
  const sipN = (parseFloat(sipYears) || 0) * 12;
  const sipTotalInvested = sipM * sipN;
  const sipFutureVal = sipM > 0 && sipR > 0 ? sipM * ((Math.pow(1 + sipR, sipN) - 1) / sipR) * (1 + sipR) : 0;
  const sipEstReturns = sipFutureVal - sipTotalInvested;

  // EMI Calculator State
  const [loanAmount, setLoanAmount] = useState("250000");
  const [loanRate, setLoanRate] = useState("7.5");
  const [loanYears, setLoanYears] = useState("15");

  const P = parseFloat(loanAmount) || 0;
  const r = (parseFloat(loanRate) || 0) / 12 / 100;
  const n = (parseFloat(loanYears) || 0) * 12;
  const emi = P > 0 && r > 0 ? (P * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1) : 0;
  const totalLoanPay = emi * n;
  const totalInterest = totalLoanPay - P;

  // Currency Converter
  const [fxAmount, setFxAmount] = useState("1000");
  const [fromFx, setFromFx] = useState("USD");
  const [toFx, setToFx] = useState("EUR");

  const fxRates: { [k: string]: number } = { USD: 1, EUR: 0.92, GBP: 0.78, INR: 83.5, JPY: 156.2, CAD: 1.36 };
  const convertedVal = ((parseFloat(fxAmount) || 0) * (fxRates[toFx] || 1)) / (fxRates[fromFx] || 1);

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
          <Calculator className="h-6 w-6 text-indigo-500" />
          Interactive Financial Calculators
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          SIP compounding, Loan EMI amortization, FIRE retirement & Currency conversion
        </p>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveCalc("sip")}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeCalc === "sip" ? "bg-indigo-600 text-white" : "text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
          }`}
        >
          SIP Compounding
        </button>
        <button
          onClick={() => setActiveCalc("emi")}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeCalc === "emi" ? "bg-indigo-600 text-white" : "text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
          }`}
        >
          Loan EMI
        </button>
        <button
          onClick={() => setActiveCalc("fx")}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeCalc === "fx" ? "bg-indigo-600 text-white" : "text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
          }`}
        >
          Currency Converter
        </button>
      </div>

      {/* SIP Calculator View */}
      {activeCalc === "sip" && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-xl">
          <div className="space-y-4 text-xs">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">SIP Mutual Fund Wealth Estimator</h3>
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Monthly Investment ($)</label>
              <input
                type="number"
                value={sipMonthly}
                onChange={(e) => setSipMonthly(e.target.value)}
                className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-slate-900 dark:text-white font-bold"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Expected Annual Return Rate (%)</label>
              <input
                type="number"
                value={sipRate}
                onChange={(e) => setSipRate(e.target.value)}
                className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-slate-900 dark:text-white font-bold"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Time Horizon (Years)</label>
              <input
                type="number"
                value={sipYears}
                onChange={(e) => setSipYears(e.target.value)}
                className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-slate-900 dark:text-white font-bold"
              />
            </div>
          </div>

          <div className="rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-5 flex flex-col justify-between">
            <div className="space-y-3">
              <div>
                <p className="text-[10px] font-bold text-slate-400 uppercase">Invested Amount</p>
                <p className="text-lg font-bold text-slate-900 dark:text-white">{formatCurrency(sipTotalInvested)}</p>
              </div>
              <div>
                <p className="text-[10px] font-bold text-slate-400 uppercase">Estimated Wealth Growth</p>
                <p className="text-lg font-bold text-emerald-500">+{formatCurrency(sipEstReturns)}</p>
              </div>
              <div className="pt-3 border-t border-slate-200 dark:border-slate-800">
                <p className="text-[10px] font-bold text-slate-400 uppercase">Total Corpus Maturity Value</p>
                <p className="text-2xl font-extrabold text-indigo-600 dark:text-cyan-400">{formatCurrency(sipFutureVal)}</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Loan EMI Calculator View */}
      {activeCalc === "emi" && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-xl">
          <div className="space-y-4 text-xs">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">Home / Auto Loan EMI Calculator</h3>
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Loan Principal Amount ($)</label>
              <input
                type="number"
                value={loanAmount}
                onChange={(e) => setLoanAmount(e.target.value)}
                className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-slate-900 dark:text-white font-bold"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Interest Rate (% p.a.)</label>
              <input
                type="number"
                step="0.1"
                value={loanRate}
                onChange={(e) => setLoanRate(e.target.value)}
                className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-slate-900 dark:text-white font-bold"
              />
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Loan Tenure (Years)</label>
              <input
                type="number"
                value={loanYears}
                onChange={(e) => setLoanYears(e.target.value)}
                className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-slate-900 dark:text-white font-bold"
              />
            </div>
          </div>

          <div className="rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-5 flex flex-col justify-between">
            <div className="space-y-3">
              <div>
                <p className="text-[10px] font-bold text-slate-400 uppercase">Monthly EMI Payment</p>
                <p className="text-2xl font-extrabold text-indigo-600 dark:text-cyan-400">{formatCurrency(emi)}/mo</p>
              </div>
              <div>
                <p className="text-[10px] font-bold text-slate-400 uppercase">Total Interest Payable</p>
                <p className="text-base font-bold text-rose-500">{formatCurrency(totalInterest)}</p>
              </div>
              <div>
                <p className="text-[10px] font-bold text-slate-400 uppercase">Total Principal + Interest</p>
                <p className="text-base font-bold text-slate-900 dark:text-white">{formatCurrency(totalLoanPay)}</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Currency Converter */}
      {activeCalc === "fx" && (
        <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-xl space-y-4 max-w-lg">
          <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <ArrowRightLeft className="h-5 w-5 text-indigo-500" />
            Live Multi-Currency Conversion
          </h3>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block font-semibold mb-1">Amount</label>
              <input
                type="number"
                value={fxAmount}
                onChange={(e) => setFxAmount(e.target.value)}
                className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-3 py-2 font-bold text-slate-900 dark:text-white"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold mb-1">From Currency</label>
                <select
                  value={fromFx}
                  onChange={(e) => setFromFx(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-slate-900 dark:text-white"
                >
                  {Object.keys(fxRates).map((c) => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold mb-1">To Currency</label>
                <select
                  value={toFx}
                  onChange={(e) => setToFx(e.target.value)}
                  className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-slate-900 dark:text-white"
                >
                  {Object.keys(fxRates).map((c) => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200 dark:border-indigo-800 text-center">
              <span className="text-[10px] uppercase font-bold text-slate-400">Converted Valuation</span>
              <p className="text-2xl font-extrabold text-indigo-600 dark:text-cyan-400 mt-1">
                {convertedVal.toFixed(2)} {toFx}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
