import React, { useState } from "react";
import { useExpenseOS } from "../../context/ExpenseContext";
import {
  Search,
  Sparkles,
  Bell,
  Sun,
  Moon,
  Wallet,
  Globe,
  PlusCircle,
  UserCheck,
  ShieldCheck,
  LogOut,
  ChevronDown,
  Lock,
} from "lucide-react";
import { CURRENCIES } from "../../data/mockData";
import { CurrencyCode, WalletType } from "../../types";
import { NotificationsPopover } from "../common/NotificationsPopover";

interface NavbarProps {
  onOpenAuth: () => void;
  onQuickAddExpense: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenAuth, onQuickAddExpense }) => {
  const {
    theme,
    toggleTheme,
    selectedCurrency,
    setSelectedCurrency,
    selectedWallet,
    setSelectedWallet,
    globalSearch,
    setGlobalSearch,
    isLoggedIn,
    logout,
    user,
    notifications,
    setActiveTab,
    setIsAiModalOpen,
  } = useExpenseOS();

  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showNotifPopover, setShowNotifPopover] = useState(false);

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  return (
    <header className="sticky top-0 z-40 w-full border-b border-white/10 bg-[#050505]/80 backdrop-blur-xl transition-colors duration-200">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Left: Brand Logo */}
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab("dashboard")}>
          <div className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-tr from-emerald-500 to-blue-600 text-white font-black text-xl shadow-[0_0_20px_rgba(16,185,129,0.3)]">
            E
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-light text-lg tracking-tight text-white">
                Financial <span className="font-bold text-white">OS</span>
              </span>
              <span className="rounded-lg bg-white/5 px-2 py-0.5 text-[10px] font-mono text-neutral-400 border border-white/10">
                STABLE_V4.2
              </span>
            </div>
            <p className="text-[10px] text-neutral-500 hidden sm:block">
              AI Intelligent Operating System
            </p>
          </div>
        </div>

        {/* Center: Global Search & Quick Actions */}
        <div className="hidden md:flex items-center flex-1 max-w-md mx-6">
          <div className="relative w-full">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-neutral-500" />
            <input
              type="text"
              placeholder="Search transactions, insights, categories (Ctrl+K)..."
              value={globalSearch}
              onChange={(e) => setGlobalSearch(e.target.value)}
              className="w-full rounded-xl border border-white/10 bg-white/5 pl-9 pr-4 py-2 text-xs text-neutral-200 placeholder-neutral-500 focus:border-emerald-500 focus:outline-none focus:ring-1 focus:ring-emerald-500 transition-all backdrop-blur-md"
            />
          </div>
        </div>

        {/* Right Controls */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Wallet Switcher */}
          <div className="relative hidden sm:flex items-center bg-white/5 rounded-lg p-1 border border-white/10 text-xs text-neutral-300">
            <Wallet className="h-3.5 w-3.5 ml-1.5 text-emerald-400" />
            <select
              value={selectedWallet}
              onChange={(e) => setSelectedWallet(e.target.value as WalletType | "all")}
              className="bg-transparent text-neutral-200 font-medium px-2 py-1 focus:outline-none cursor-pointer"
            >
              <option value="all" className="bg-neutral-950">All Wallets</option>
              <option value="personal" className="bg-neutral-950">Personal</option>
              <option value="family" className="bg-neutral-950">Family</option>
              <option value="business" className="bg-neutral-950">Business</option>
            </select>
          </div>

          {/* Currency Switcher */}
          <div className="relative hidden sm:flex items-center bg-white/5 rounded-lg p-1 border border-white/10 text-xs text-neutral-300">
            <Globe className="h-3.5 w-3.5 ml-1.5 text-neutral-500" />
            <select
              value={selectedCurrency}
              onChange={(e) => setSelectedCurrency(e.target.value as CurrencyCode)}
              className="bg-transparent text-neutral-200 font-medium px-2 py-1 focus:outline-none cursor-pointer"
            >
              {Object.keys(CURRENCIES).map((code) => (
                <option key={code} value={code} className="bg-neutral-950">
                  {code} ({CURRENCIES[code].symbol})
                </option>
              ))}
            </select>
          </div>

          {/* AI CFO Advisor Launcher Button */}
          <button
            onClick={() => setActiveTab("ai-cfo")}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-blue-600/20 border border-blue-500/30 text-blue-400 hover:bg-blue-600/30 font-medium text-xs transition-all cursor-pointer"
          >
            <Sparkles className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">AI Insights</span>
          </button>

          {/* New Transaction Button (White button from Elegant Dark design) */}
          <button
            onClick={onQuickAddExpense}
            className="flex items-center gap-1.5 px-4 py-2 bg-white text-black font-semibold text-xs rounded-lg hover:bg-neutral-200 transition-colors shadow-md cursor-pointer"
          >
            <PlusCircle className="h-3.5 w-3.5 text-black" />
            <span className="hidden sm:inline">+ Transaction</span>
          </button>

          {/* Notifications Bell */}
          <div className="relative">
            <button
              onClick={() => setShowNotifPopover(!showNotifPopover)}
              className="relative p-2 rounded-lg text-neutral-400 hover:text-white hover:bg-white/5 transition-colors cursor-pointer border border-transparent hover:border-white/10"
            >
              <Bell className="h-4 w-4" />
              {unreadCount > 0 && (
                <span className="absolute top-1 right-1 flex h-3.5 w-3.5 items-center justify-center rounded-full bg-emerald-500 text-[9px] font-bold text-black">
                  {unreadCount}
                </span>
              )}
            </button>
            {showNotifPopover && (
              <NotificationsPopover onClose={() => setShowNotifPopover(false)} />
            )}
          </div>

          {/* Theme Toggle */}
          <button
            onClick={toggleTheme}
            className="p-2 rounded-lg text-neutral-400 hover:text-white hover:bg-white/5 transition-colors cursor-pointer border border-transparent hover:border-white/10"
            title="Toggle Dark/Light Mode"
          >
            {theme === "dark" ? <Sun className="h-4 w-4 text-amber-400" /> : <Moon className="h-4 w-4 text-emerald-400" />}
          </button>

          {/* User Auth Profile Menu */}
          {isLoggedIn ? (
            <div className="relative">
              <button
                onClick={() => setShowProfileMenu(!showProfileMenu)}
                className="flex items-center gap-2 p-1 rounded-xl hover:bg-white/5 transition-all cursor-pointer border border-transparent hover:border-white/10"
              >
                <div className="w-8 h-8 rounded-full border-2 border-emerald-500 p-0.5">
                  <img
                    src={user.avatar}
                    alt={user.name}
                    className="w-full h-full rounded-full object-cover"
                  />
                </div>
                <ChevronDown className="h-3.5 w-3.5 text-neutral-400 hidden sm:block" />
              </button>

              {showProfileMenu && (
                <div className="absolute right-0 mt-2 w-56 rounded-2xl border border-white/10 bg-neutral-950 p-2 shadow-2xl backdrop-blur-xl z-50 animate-in fade-in zoom-in-95 duration-150">
                  <div className="px-3 py-2 border-b border-white/10">
                    <p className="text-xs font-bold text-white">{user.name}</p>
                    <p className="text-[11px] text-neutral-500 truncate">{user.email}</p>
                    <div className="mt-1 flex items-center gap-2">
                      <span className="inline-block rounded-full bg-emerald-500/10 px-2 py-0.5 text-[10px] font-semibold text-emerald-400 border border-emerald-500/20">
                        {user.role} ({user.tier})
                      </span>
                      <span className="text-[10px] text-emerald-500 font-mono font-bold">Lvl {user.level}</span>
                    </div>
                  </div>
                  <div className="py-1">
                    <button
                      onClick={() => {
                        setActiveTab("security");
                        setShowProfileMenu(false);
                      }}
                      className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-xs text-neutral-300 hover:bg-white/5 hover:text-white"
                    >
                      <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" />
                      Security & Vault
                    </button>
                    <button
                      onClick={() => {
                        setActiveTab("admin");
                        setShowProfileMenu(false);
                      }}
                      className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-xs text-neutral-300 hover:bg-white/5 hover:text-white"
                    >
                      <UserCheck className="h-3.5 w-3.5 text-blue-400" />
                      Admin Control
                    </button>
                  </div>
                  <div className="pt-1 border-t border-white/10">
                    <button
                      onClick={() => {
                        logout();
                        setShowProfileMenu(false);
                      }}
                      className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-xs font-semibold text-rose-400 hover:bg-rose-500/10"
                    >
                      <LogOut className="h-3.5 w-3.5" />
                      Sign Out
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <button
              onClick={onOpenAuth}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-white/10 bg-white/5 hover:bg-white/10 text-white font-semibold text-xs transition-all cursor-pointer"
            >
              <Lock className="h-3.5 w-3.5 text-emerald-400" />
              Sign In
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
