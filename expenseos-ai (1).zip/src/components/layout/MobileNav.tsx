import React from "react";
import { useExpenseOS, NavTab } from "../../context/ExpenseContext";
import {
  LayoutDashboard,
  Receipt,
  TrendingUp,
  PieChart,
} from "lucide-react";

export const MobileNav: React.FC<{ onToggleDrawer: () => void }> = () => {
  const { activeTab, setActiveTab } = useExpenseOS();

  const items: { id: NavTab; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
    { id: "dashboard", label: "Home", icon: LayoutDashboard },
    { id: "income", label: "Salary", icon: TrendingUp },
    { id: "expenses", label: "Expenses", icon: Receipt },
    { id: "budget", label: "Budget", icon: PieChart },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-[#050505]/95 backdrop-blur-xl border-t border-white/10 lg:hidden px-2 py-1.5 flex items-center justify-around shadow-2xl">
      {items.map((item) => {
        const Icon = item.icon;
        const isActive = activeTab === item.id;

        return (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`flex flex-col items-center py-1 px-3 rounded-xl text-[10px] font-medium transition-all cursor-pointer ${
              isActive
                ? "text-white font-semibold"
                : "text-neutral-500 hover:text-white"
            }`}
          >
            <Icon className={`h-5 w-5 ${isActive ? "text-emerald-400 scale-110" : ""}`} />
            <span className="mt-1">{item.label}</span>
          </button>
        );
      })}
    </div>
  );
};
