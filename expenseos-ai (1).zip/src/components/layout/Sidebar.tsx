import React from "react";
import { useExpenseOS, NavTab } from "../../context/ExpenseContext";
import {
  Home,
  LayoutDashboard,
  Receipt,
  TrendingUp,
  PieChart,
  Sparkles,
  BarChart3,
  Target,
  Repeat,
  CalendarCheck,
  Calculator,
  Trophy,
  BookOpen,
  ShieldAlert,
  Sliders,
  Flame,
} from "lucide-react";

interface NavItem {
  id: NavTab;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: string;
  isAi?: boolean;
}

export const Sidebar: React.FC = () => {
  const { activeTab, setActiveTab, user, expenses, subscriptions, bills } = useExpenseOS();

  const unusedSubs = subscriptions.filter((s) => s.status === "flagged_unused").length;
  const pendingBills = bills.filter((b) => !b.isPaid).length;

  const navItems: NavItem[] = [
    { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
    { id: "income", label: "Monthly Salary", icon: TrendingUp },
    { id: "expenses", label: "Expenses", icon: Receipt, badge: `${expenses.length}` },
    { id: "budget", label: "Budgets & Categories", icon: PieChart },
  ];

  return (
    <aside className="w-64 border-r border-white/10 bg-neutral-950 hidden lg:flex flex-col justify-between py-6 px-4 sticky top-16 h-[calc(100vh-4rem)] overflow-y-auto">
      {/* Upper Navigation List */}
      <div className="space-y-1">
        <div className="px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-neutral-500 font-mono">
          System Navigation
        </div>

        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex w-full items-center justify-between rounded-xl px-3.5 py-2.5 text-xs font-medium transition-all duration-150 cursor-pointer ${
                isActive
                  ? "bg-white/10 text-white border border-white/15 font-semibold shadow-inner"
                  : "text-neutral-400 hover:bg-white/5 hover:text-white"
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon
                  className={`h-4 w-4 ${
                    isActive
                      ? "text-white"
                      : item.isAi
                      ? "text-blue-400"
                      : "text-neutral-500"
                  }`}
                />
                <span>{item.label}</span>
              </div>

              {item.badge && (
                <span
                  className={`rounded-md px-2 py-0.5 text-[10px] font-mono font-bold ${
                    isActive
                      ? "bg-emerald-500 text-black"
                      : item.isAi
                      ? "bg-blue-500/20 text-blue-400 border border-blue-500/30"
                      : "bg-white/5 text-neutral-400 border border-white/10"
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Footer Level Stats */}
      <div className="pt-4 border-t border-white/10">
        <div className="rounded-2xl bg-white/5 p-4 border border-white/10 backdrop-blur-xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Flame className="h-4 w-4 text-emerald-400 animate-pulse" />
              <span className="text-xs font-bold text-white">
                {user.streakDays} Day Streak
              </span>
            </div>
            <span className="text-[10px] font-mono font-bold text-emerald-400">LVL {user.level}</span>
          </div>

          <div className="mt-2.5 w-full bg-neutral-900 rounded-full h-1.5 overflow-hidden border border-white/5">
            <div
              className="bg-gradient-to-r from-emerald-500 to-blue-500 h-full rounded-full transition-all duration-300"
              style={{ width: `${(user.xpPoints % 1000) / 10}%` }}
            ></div>
          </div>
          <p className="text-[10px] font-mono text-neutral-500 mt-1.5">
            {user.xpPoints} XP • {1000 - (user.xpPoints % 1000)} XP to Lvl {user.level + 1}
          </p>
        </div>
      </div>
    </aside>
  );
};
