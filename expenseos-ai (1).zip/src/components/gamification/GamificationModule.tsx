import React, { useState } from "react";
import { useExpenseOS } from "../../context/ExpenseContext";
import { Trophy, Flame, Award, Zap, CheckCircle2, HelpCircle, Sparkles } from "lucide-react";
import confetti from "canvas-confetti";

export const GamificationModule: React.FC = () => {
  const { user, addNotification } = useExpenseOS();

  const [xp, setXp] = useState(user.xp);
  const [level, setLevel] = useState(user.level);
  const [selectedQuiz, setSelectedQuiz] = useState<number | null>(null);

  const quizQuestions = [
    {
      question: "What is the 50/30/20 budgeting rule?",
      options: [
        "50% Needs, 30% Wants, 20% Savings",
        "50% Rent, 30% Food, 20% Crypto",
        "50% Taxes, 30% Savings, 20% Shopping",
      ],
      correct: 0,
    },
    {
      question: "Which ratio represents the Emergency Reserve Fund benchmark?",
      options: ["1 month expense", "3 to 6 months of living expenses", "10 years of salary"],
      correct: 1,
    },
  ];

  const handleAnswer = (qIdx: number, optIdx: number) => {
    setSelectedQuiz(optIdx);
    if (optIdx === quizQuestions[qIdx].correct) {
      confetti({ particleCount: 80, spread: 60, origin: { y: 0.6 } });
      setXp((prev) => prev + 150);
      addNotification("Quiz Champion!", "Correct answer! +150 XP Earned.", "success");
    } else {
      addNotification("Incorrect", "Review the budgeting principles and try again.", "info");
    }
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
          <Trophy className="h-6 w-6 text-amber-500" />
          Financial Mastery & Gamification Hub
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Daily logging streaks, level achievements, badges & financial literacy quizzes
        </p>
      </div>

      {/* Profile Level Bar */}
      <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-tr from-amber-400 to-amber-600 text-slate-950 font-extrabold text-xl shadow-lg shadow-amber-500/30">
              Lvl {level}
            </div>
            <div>
              <h2 className="text-lg font-extrabold text-white">{user.name}</h2>
              <p className="text-xs text-cyan-300 font-medium">Rank: Master Financial Strategist</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 rounded-2xl bg-white/10 px-4 py-2 border border-white/10">
              <Flame className="h-5 w-5 text-amber-400 animate-bounce" />
              <div>
                <span className="text-[10px] text-slate-400 font-bold block">STREAK</span>
                <span className="text-sm font-extrabold text-white">{user.streakDays} Days Active</span>
              </div>
            </div>

            <div className="flex items-center gap-2 rounded-2xl bg-white/10 px-4 py-2 border border-white/10">
              <Zap className="h-5 w-5 text-cyan-400" />
              <div>
                <span className="text-[10px] text-slate-400 font-bold block">TOTAL XP</span>
                <span className="text-sm font-extrabold text-cyan-300">{xp} XP</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Badges Grid */}
      <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-xl space-y-3">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <Award className="h-4 w-4 text-indigo-500" />
          Unlocked Badges & Medals ({user.badges.length})
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {user.badges.map((badge, idx) => (
            <div key={idx} className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/60 text-center">
              <div className="mx-auto mb-2 flex h-10 w-10 items-center justify-center rounded-xl bg-amber-500/10 text-amber-500">
                <Trophy className="h-5 w-5" />
              </div>
              <p className="text-xs font-bold text-slate-800 dark:text-slate-200">{badge}</p>
              <span className="text-[9px] text-emerald-500 font-semibold">Unlocked</span>
            </div>
          ))}
        </div>
      </div>

      {/* Quiz Challenge */}
      <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-xl space-y-4">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <HelpCircle className="h-4 w-4 text-cyan-500" />
          Daily Financial Quiz (+150 XP Reward)
        </h3>

        <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-3">
          <p className="text-xs font-bold text-slate-900 dark:text-white">{quizQuestions[0].question}</p>
          <div className="space-y-2">
            {quizQuestions[0].options.map((opt, oIdx) => (
              <button
                key={oIdx}
                onClick={() => handleAnswer(0, oIdx)}
                className={`w-full text-left p-2.5 rounded-xl text-xs font-medium border transition-all cursor-pointer ${
                  selectedQuiz === oIdx
                    ? oIdx === quizQuestions[0].correct
                      ? "bg-emerald-500/20 border-emerald-500 text-emerald-600 dark:text-emerald-400"
                      : "bg-rose-500/20 border-rose-500 text-rose-600 dark:text-rose-400"
                    : "border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800"
                }`}
              >
                {opt}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
