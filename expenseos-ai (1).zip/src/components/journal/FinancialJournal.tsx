import React, { useState } from "react";
import { BookOpen, Smile, Frown, Meh, Heart, Sparkles, Plus } from "lucide-react";

export const FinancialJournal: React.FC = () => {
  const [entries, setEntries] = useState([
    {
      id: "j-1",
      date: "2026-07-29",
      mood: "Confident",
      note: "Saved $450 by cooking meals at home and re-investing the savings into S&P 500 index funds.",
      impact: "Positive",
    },
    {
      id: "j-2",
      date: "2026-07-28",
      mood: "Anxious",
      note: "Impulse tech purchase at Gadget Store ($450). Regretted after realizing it wasn't strictly essential.",
      impact: "Caution",
    },
  ]);

  const [mood, setMood] = useState("Confident");
  const [note, setNote] = useState("");

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!note) return;
    setEntries([
      {
        id: "j-" + Date.now(),
        date: new Date().toISOString().split("T")[0],
        mood,
        note,
        impact: "Positive",
      },
      ...entries,
    ]);
    setNote("");
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
          <BookOpen className="h-6 w-6 text-indigo-500" />
          Financial Psychology & Mood Journal
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Track emotional triggers behind spending habits & build mindful money discipline
        </p>
      </div>

      <form onSubmit={handleAdd} className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-xl space-y-4">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white">Record Money Mindset Log</h3>

        <div className="grid grid-cols-3 gap-2 text-xs">
          {["Confident", "Neutral", "Anxious"].map((m) => (
            <button
              key={m}
              type="button"
              onClick={() => setMood(m)}
              className={`p-2.5 rounded-xl border font-bold cursor-pointer transition-all ${
                mood === m ? "bg-indigo-600 text-white border-indigo-600" : "border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400"
              }`}
            >
              {m}
            </button>
          ))}
        </div>

        <textarea
          rows={3}
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="Reflect on today's financial decision..."
          className="w-full rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3 text-xs text-slate-900 dark:text-white focus:outline-none"
        ></textarea>

        <button type="submit" className="px-4 py-2.5 rounded-xl bg-indigo-600 text-white text-xs font-bold cursor-pointer shadow-md shadow-indigo-500/20">
          Save Reflection Entry
        </button>
      </form>

      <div className="space-y-3">
        {entries.map((item) => (
          <div key={item.id} className="p-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-md text-xs space-y-1">
            <div className="flex items-center justify-between text-slate-400 text-[10px]">
              <span>{item.date} • Mood: <strong className="text-indigo-500">{item.mood}</strong></span>
            </div>
            <p className="text-slate-800 dark:text-slate-200">{item.note}</p>
          </div>
        ))}
      </div>
    </div>
  );
};
