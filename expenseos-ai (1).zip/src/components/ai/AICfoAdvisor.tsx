import React, { useState } from "react";
import { useExpenseOS } from "../../context/ExpenseContext";
import { Sparkles, Send, Bot, User, Loader2, ArrowRight, Lightbulb, Zap, ShieldAlert, Cpu } from "lucide-react";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: string;
}

export const AICfoAdvisor: React.FC = () => {
  const { metrics, expenses, incomeList, subscriptions, goals, formatCurrency } = useExpenseOS();

  const [inputMsg, setInputMsg] = useState("");
  const [loading, setLoading] = useState(false);

  const initialMsgs: Message[] = [
    {
      id: "m-1",
      role: "assistant",
      content: `### Welcome to ExpenseOS AI CFO Intelligence
I have analyzed your **$${metrics.netWorth.toLocaleString()} Net Worth**, **${metrics.savingsRate}% Savings Rate**, and recent transactions across all wallets.

**Your Financial Status:**
• **Financial Health Score:** **${metrics.financialHealthScore}/100** (Optimal)
• **Emergency Fund Cushion:** $${metrics.emergencyFundAmount.toLocaleString()} Reserve
• **Top CFO Recommendation:** Reallocate $3,000 idle checking cash to high-yield 5.2% APY money market funds.

Ask me anything about your finances, feasibility of major purchases, waste detection, or tax strategies!`,
      timestamp: "Just now",
    },
  ];

  const [messages, setMessages] = useState<Message[]>(initialMsgs);

  const handleSend = async (promptText?: string) => {
    const textToSend = promptText || inputMsg;
    if (!textToSend.trim()) return;

    const userMessage: Message = {
      id: "msg-" + Date.now(),
      role: "user",
      content: textToSend,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    setMessages((prev) => [...prev, userMessage]);
    if (!promptText) setInputMsg("");
    setLoading(true);

    try {
      const res = await fetch("/api/ai/financial-advisor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: [...messages, userMessage].map((m) => ({ role: m.role, content: m.content })),
          userFinancialContext: {
            metrics,
            expensesCount: expenses.length,
            incomeSources: incomeList.map((i) => i.source),
            unusedSubscriptions: subscriptions.filter((s) => s.status === "flagged_unused").map((s) => s.name),
            financialGoals: goals.map((g) => ({ title: g.title, progress: `${g.currentAmount}/${g.targetAmount}` })),
          },
        }),
      });

      const data = await res.json();
      const replyText = data.response || "I have analyzed your financial request.";

      const aiMsg: Message = {
        id: "msg-ai-" + Date.now(),
        role: "assistant",
        content: replyText,
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      };

      setMessages((prev) => [...prev, aiMsg]);
    } catch (error) {
      console.error("AI CFO Error:", error);
    } finally {
      setLoading(false);
    }
  };

  const quickPrompts = [
    "Where am I wasting money?",
    "Can I buy a $1,200 laptop?",
    "Will I run out of money in 6 months?",
    "How much can I safely invest this month?",
    "Recommend subscriptions to cancel",
  ];

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
            <Sparkles className="h-6 w-6 text-indigo-500 animate-pulse" />
            AI Financial Advisor & CFO Engine
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Powered by Google Gemini 3.6 Flash • Server-side secure intelligence
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="rounded-full bg-emerald-500/10 px-3 py-1 text-xs font-bold text-emerald-500 border border-emerald-500/20 flex items-center gap-1.5">
            <Cpu className="h-3.5 w-3.5" />
            Gemini Engine Ready
          </span>
        </div>
      </div>

      {/* Main Chat Container */}
      <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xl overflow-hidden flex flex-col h-[650px]">
        {/* Quick Prompt Chips */}
        <div className="p-3 bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800 flex items-center gap-2 overflow-x-auto">
          <span className="text-[10px] font-bold uppercase text-slate-400 whitespace-nowrap pl-2">
            Quick Analysis:
          </span>
          {quickPrompts.map((p, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(p)}
              className="rounded-xl border border-indigo-200 dark:border-indigo-800/60 bg-white dark:bg-slate-900 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-indigo-50 dark:hover:bg-indigo-950/80 hover:text-indigo-600 dark:hover:text-cyan-400 whitespace-nowrap transition-colors cursor-pointer"
            >
              {p}
            </button>
          ))}
        </div>

        {/* Message Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          {messages.map((m) => (
            <div
              key={m.id}
              className={`flex gap-3 max-w-3xl ${
                m.role === "user" ? "ml-auto flex-row-reverse" : "mr-auto"
              }`}
            >
              <div
                className={`flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-xl font-bold text-xs ${
                  m.role === "user"
                    ? "bg-indigo-600 text-white"
                    : "bg-gradient-to-tr from-cyan-500 to-indigo-600 text-white"
                }`}
              >
                {m.role === "user" ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
              </div>

              <div
                className={`rounded-2xl p-4 text-xs leading-relaxed shadow-sm ${
                  m.role === "user"
                    ? "bg-indigo-600 text-white rounded-tr-none"
                    : "bg-slate-100 dark:bg-slate-800/80 text-slate-900 dark:text-slate-100 rounded-tl-none border border-slate-200 dark:border-slate-700/60"
                }`}
              >
                <div className="whitespace-pre-wrap">{m.content}</div>
                <span className="block mt-2 text-[9px] opacity-60 text-right">{m.timestamp}</span>
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex gap-3 max-w-xl mr-auto">
              <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-indigo-600 text-white">
                <Bot className="h-4 w-4" />
              </div>
              <div className="rounded-2xl bg-slate-100 dark:bg-slate-800 p-4 text-xs text-slate-500 flex items-center gap-2">
                <Loader2 className="h-4 w-4 animate-spin text-indigo-500" />
                <span>ExpenseOS AI CFO calculating financial probability models...</span>
              </div>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="p-3 bg-slate-50 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 flex items-center gap-2"
        >
          <input
            type="text"
            value={inputMsg}
            onChange={(e) => setInputMsg(e.target.value)}
            placeholder="Ask AI CFO: 'Where am I wasting money?' or 'Can I afford a $1200 laptop?'"
            className="flex-1 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3 text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:border-indigo-500"
          />

          <button
            type="submit"
            disabled={loading || !inputMsg.trim()}
            className="flex items-center gap-2 rounded-2xl bg-gradient-to-r from-indigo-600 via-purple-600 to-cyan-600 px-5 py-3 text-xs font-bold text-white shadow-lg shadow-indigo-500/25 hover:opacity-95 disabled:opacity-50 cursor-pointer"
          >
            <span>Ask AI</span>
            <Send className="h-3.5 w-3.5" />
          </button>
        </form>
      </div>
    </div>
  );
};
