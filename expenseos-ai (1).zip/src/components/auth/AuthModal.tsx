import React, { useState } from "react";
import { useExpenseOS } from "../../context/ExpenseContext";
import { X, Lock, Mail, User, KeyRound, ShieldCheck, ArrowRight, CheckCircle2 } from "lucide-react";

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose }) => {
  const { login } = useExpenseOS();

  const [mode, setMode] = useState<"login" | "signup" | "forgot" | "otp" | "2fa">("login");
  const [email, setEmail] = useState("alex.vance@expenseos.ai");
  const [password, setPassword] = useState("••••••••••••");
  const [name, setName] = useState("Alex Vance");
  const [otpCode, setOtpCode] = useState(["4", "8", "1", "9"]);
  const [stepSuccess, setStepSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (mode === "login") {
      login(email, password);
      onClose();
    } else if (mode === "signup") {
      setMode("otp");
    } else if (mode === "otp") {
      setStepSuccess(true);
      setTimeout(() => {
        login(email, password);
        onClose();
      }, 1000);
    } else if (mode === "forgot") {
      setStepSuccess(true);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-md rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 sm:p-8 shadow-2xl overflow-hidden">
        {/* Glow ambient decoration */}
        <div className="absolute -top-12 -right-12 h-32 w-32 rounded-full bg-indigo-500/20 blur-2xl pointer-events-none"></div>
        <div className="absolute -bottom-12 -left-12 h-32 w-32 rounded-full bg-cyan-500/20 blur-2xl pointer-events-none"></div>

        <button
          onClick={onClose}
          className="absolute right-4 top-4 p-2 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        >
          <X className="h-5 w-5" />
        </button>

        <div className="mb-6 text-center">
          <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-tr from-indigo-600 to-cyan-500 text-white shadow-lg shadow-indigo-500/30">
            <Lock className="h-6 w-6" />
          </div>
          <h3 className="text-xl font-extrabold text-slate-900 dark:text-white">
            {mode === "login" && "Sign In to ExpenseOS AI"}
            {mode === "signup" && "Create Financial OS Account"}
            {mode === "forgot" && "Reset Your Password"}
            {mode === "otp" && "Verify Email Code"}
            {mode === "2fa" && "Two-Factor Authentication"}
          </h3>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            {mode === "login" && "Secure end-to-end encrypted personal finance workspace"}
            {mode === "signup" && "Unlock AI financial intelligence and receipt scanner"}
            {mode === "forgot" && "We will send an OTP code to your registered email"}
            {mode === "otp" && "Enter the 4-digit code sent to your email"}
          </p>
        </div>

        {stepSuccess ? (
          <div className="py-8 text-center space-y-3">
            <CheckCircle2 className="mx-auto h-12 w-12 text-emerald-500 animate-bounce" />
            <h4 className="font-bold text-base text-slate-900 dark:text-white">Verification Complete!</h4>
            <p className="text-xs text-slate-500">Redirecting to your financial operating system dashboard...</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            {mode === "signup" && (
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Full Name
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 pl-9 pr-4 py-2.5 text-xs text-slate-900 dark:text-slate-100 focus:border-indigo-500 focus:outline-none"
                    placeholder="Alex Vance"
                  />
                </div>
              </div>
            )}

            {(mode === "login" || mode === "signup" || mode === "forgot") && (
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 pl-9 pr-4 py-2.5 text-xs text-slate-900 dark:text-slate-100 focus:border-indigo-500 focus:outline-none"
                    placeholder="alex@example.com"
                  />
                </div>
              </div>
            )}

            {(mode === "login" || mode === "signup") && (
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                    Password
                  </label>
                  {mode === "login" && (
                    <button
                      type="button"
                      onClick={() => setMode("forgot")}
                      className="text-[11px] font-medium text-indigo-500 hover:underline"
                    >
                      Forgot?
                    </button>
                  )}
                </div>
                <div className="relative">
                  <KeyRound className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 pl-9 pr-4 py-2.5 text-xs text-slate-900 dark:text-slate-100 focus:border-indigo-500 focus:outline-none"
                  />
                </div>
              </div>
            )}

            {mode === "otp" && (
              <div className="flex justify-center gap-3 my-4">
                {otpCode.map((digit, idx) => (
                  <input
                    key={idx}
                    type="text"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => {
                      const copy = [...otpCode];
                      copy[idx] = e.target.value;
                      setOtpCode(copy);
                    }}
                    className="h-12 w-12 text-center text-lg font-bold rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white focus:border-indigo-500 focus:outline-none"
                  />
                ))}
              </div>
            )}

            <button
              type="submit"
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-indigo-600 via-purple-600 to-cyan-600 py-3 text-xs font-bold text-white shadow-lg shadow-indigo-500/25 hover:opacity-95 transition-all cursor-pointer"
            >
              <span>
                {mode === "login" && "Authenticate Session"}
                {mode === "signup" && "Send Verification Code"}
                {mode === "otp" && "Confirm OTP & Sign In"}
                {mode === "forgot" && "Send Password Reset Link"}
              </span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </form>
        )}

        {/* Social Auth Options */}
        {mode === "login" && !stepSuccess && (
          <div className="mt-6 border-t border-slate-100 dark:border-slate-800 pt-4">
            <p className="text-center text-[10px] uppercase tracking-wider text-slate-400 font-bold mb-3">
              Or continue with
            </p>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => {
                  login(email, password);
                  onClose();
                }}
                className="flex items-center justify-center gap-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <span>Google</span>
              </button>
              <button
                onClick={() => {
                  login(email, password);
                  onClose();
                }}
                className="flex items-center justify-center gap-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <span>GitHub</span>
              </button>
            </div>
          </div>
        )}

        <div className="mt-6 text-center text-xs text-slate-500">
          {mode === "login" ? (
            <p>
              Don't have an account?{" "}
              <button onClick={() => setMode("signup")} className="font-bold text-indigo-500 hover:underline">
                Create one
              </button>
            </p>
          ) : (
            <p>
              Already registered?{" "}
              <button onClick={() => setMode("login")} className="font-bold text-indigo-500 hover:underline">
                Sign In
              </button>
            </p>
          )}
        </div>
      </div>
    </div>
  );
};
