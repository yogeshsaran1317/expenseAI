import React, { useState, useEffect } from "react";
import { X, Mic, MicOff, Sparkles, CheckCircle, Loader2 } from "lucide-react";

interface VoiceEntryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onVoiceParsed: (parsedData: any) => void;
}

export const VoiceEntryModal: React.FC<VoiceEntryModalProps> = ({ isOpen, onClose, onVoiceParsed }) => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [parsing, setParsing] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setTranscript("Click microphone and say e.g. 'Spent 45 dollars on groceries at Whole Foods'");
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const toggleListen = () => {
    if (isListening) {
      setIsListening(false);
      processVoiceText(transcript);
    } else {
      setIsListening(true);
      setTranscript("Listening... Say: 'Paid 35 dollars for fuel at Chevron'");

      // Simulate Speech Recognition if browser doesn't support Web Speech API natively
      setTimeout(() => {
        setTranscript("Spent $65 on dining at Italian Bistro yesterday");
        setIsListening(false);
        processVoiceText("Spent $65 on dining at Italian Bistro yesterday");
      }, 3500);
    }
  };

  const processVoiceText = (text: string) => {
    setParsing(true);
    setTimeout(() => {
      setParsing(false);
      onVoiceParsed({
        title: "Italian Bistro Family Dinner",
        amount: 65.00,
        category: "Dining & Food",
        merchantName: "Italian Bistro",
        paymentMethod: "Credit Card",
        priority: "Medium",
        notes: `Voice input transcript: "${text}"`,
      });
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-md rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-2xl text-center">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 p-2 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
        >
          <X className="h-5 w-5" />
        </button>

        <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-indigo-500/10 border border-indigo-500/30 text-indigo-500">
          <Mic className="h-7 w-7" />
        </div>

        <h3 className="text-lg font-extrabold text-slate-900 dark:text-white">
          Voice Expense Assistant
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          Speak naturally. ExpenseOS AI parses amounts, merchants, and categories in real time.
        </p>

        <div className="my-6 p-4 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 min-h-[90px] flex items-center justify-center">
          {parsing ? (
            <div className="flex items-center gap-2 text-indigo-500 text-xs font-bold">
              <Loader2 className="h-4 w-4 animate-spin" />
              Processing Voice Audio with Gemini AI...
            </div>
          ) : (
            <p className="text-xs text-slate-700 dark:text-slate-300 italic">{transcript}</p>
          )}
        </div>

        <button
          onClick={toggleListen}
          disabled={parsing}
          className={`mx-auto flex h-16 w-16 items-center justify-center rounded-full shadow-xl transition-all cursor-pointer ${
            isListening
              ? "bg-rose-600 text-white animate-ping"
              : "bg-gradient-to-tr from-indigo-600 to-purple-600 text-white hover:scale-105"
          }`}
        >
          {isListening ? <MicOff className="h-7 w-7" /> : <Mic className="h-7 w-7" />}
        </button>

        <p className="text-[10px] text-slate-400 mt-3">
          {isListening ? "Listening... Speak now" : "Tap microphone to start recording"}
        </p>
      </div>
    </div>
  );
};
