import React, { useState } from "react";
import { useExpenseOS } from "../../context/ExpenseContext";
import { CategoryType, PaymentMethod, ExpensePriority, WalletType, Expense } from "../../types";
import { CURRENCIES } from "../../data/mockData";
import {
  Calendar,
  Plus,
  Trash2,
  X,
  CheckCircle2,
  Zap,
  DollarSign,
  FileText,
  ListPlus,
  ArrowRight,
  Sparkles,
} from "lucide-react";

interface DailyExpenseRow {
  id: string;
  title: string;
  category: CategoryType;
  amount: string;
  paymentMethod: PaymentMethod;
  merchantName?: string;
  wallet: WalletType;
  notes?: string;
}

const CATEGORY_OPTIONS: CategoryType[] = [
  "Groceries",
  "Dining & Food",
  "Transport & Fuel",
  "Electronics",
  "Subscriptions",
  "Investment",
  "Healthcare",
  "Bills & Utilities",
  "Shopping",
  "Other",
];

const PAYMENT_METHODS: PaymentMethod[] = ["UPI", "Credit Card", "Debit Card", "Cash", "Bank Transfer"];

export const DailyBatchExpenseModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
}> = ({ isOpen, onClose }) => {
  const { addBulkExpenses, selectedCurrency, formatCurrency } = useExpenseOS();
  const currSymbol = CURRENCIES[selectedCurrency]?.symbol || "₹";

  const [date, setDate] = useState<string>(new Date().toISOString().split("T")[0]);
  const [activeTab, setActiveTab] = useState<"table" | "quicktext">("table");

  // Multi-row state
  const [rows, setRows] = useState<DailyExpenseRow[]>([
    {
      id: "row-1",
      title: "Morning Coffee / Tea",
      category: "Dining & Food",
      amount: "60",
      paymentMethod: "UPI",
      wallet: "personal",
    },
    {
      id: "row-2",
      title: "Daily Office Commute / Metro",
      category: "Transport & Fuel",
      amount: "150",
      paymentMethod: "UPI",
      wallet: "personal",
    },
    {
      id: "row-3",
      title: "Lunch / Food",
      category: "Dining & Food",
      amount: "220",
      paymentMethod: "UPI",
      wallet: "personal",
    },
  ]);

  // Quick text input state
  const [rawText, setRawText] = useState(
    "Groceries 450 UPI\nEvening Snacks 120 Cash\nMedicine 280 Debit Card"
  );

  if (!isOpen) return null;

  const handleAddRow = () => {
    setRows((prev) => [
      ...prev,
      {
        id: "row-" + Date.now() + Math.random(),
        title: "",
        category: "Dining & Food",
        amount: "",
        paymentMethod: "UPI",
        wallet: "personal",
      },
    ]);
  };

  const handleRemoveRow = (id: string) => {
    if (rows.length <= 1) return;
    setRows((prev) => prev.filter((r) => r.id !== id));
  };

  const handleRowChange = (id: string, field: keyof DailyExpenseRow, value: string) => {
    setRows((prev) =>
      prev.map((r) => (r.id === id ? { ...r, [field]: value } : r))
    );
  };

  // Quick text parser helper
  const parseQuickText = () => {
    const lines = rawText.split("\n").filter((l) => l.trim().length > 0);
    const parsedRows: DailyExpenseRow[] = lines.map((line, idx) => {
      const parts = line.trim().split(/\s+/);
      let amt = "0";
      let titleParts: string[] = [];
      let payMethod: PaymentMethod = "UPI";

      for (const part of parts) {
        if (!isNaN(parseFloat(part)) && isFinite(Number(part))) {
          amt = part;
        } else if (["upi", "cash", "card", "debit", "credit"].includes(part.toLowerCase())) {
          if (part.toLowerCase().includes("cash")) payMethod = "Cash";
          else if (part.toLowerCase().includes("credit")) payMethod = "Credit Card";
          else if (part.toLowerCase().includes("debit")) payMethod = "Debit Card";
          else payMethod = "UPI";
        } else {
          titleParts.push(part);
        }
      }

      const title = titleParts.join(" ") || `Daily Expense #${idx + 1}`;
      let category: CategoryType = "Other";
      const lowerTitle = title.toLowerCase();

      if (lowerTitle.includes("tea") || lowerTitle.includes("coffee") || lowerTitle.includes("lunch") || lowerTitle.includes("food") || lowerTitle.includes("snack") || lowerTitle.includes("dinner")) {
        category = "Dining & Food";
      } else if (lowerTitle.includes("grocery") || lowerTitle.includes("milk") || lowerTitle.includes("vegetable") || lowerTitle.includes("fruit")) {
        category = "Groceries";
      } else if (lowerTitle.includes("petrol") || lowerTitle.includes("fuel") || lowerTitle.includes("metro") || lowerTitle.includes("uber") || lowerTitle.includes("auto") || lowerTitle.includes("cab") || lowerTitle.includes("bus")) {
        category = "Transport & Fuel";
      } else if (lowerTitle.includes("medicine") || lowerTitle.includes("doctor") || lowerTitle.includes("pharmacy")) {
        category = "Healthcare";
      }

      return {
        id: "parsed-" + idx + Date.now(),
        title,
        category,
        amount: amt,
        paymentMethod: payMethod,
        wallet: "personal",
      };
    });

    if (parsedRows.length > 0) {
      setRows(parsedRows);
      setActiveTab("table");
    }
  };

  // Calculate day total
  const calculatedTotal = rows.reduce((sum, r) => sum + (parseFloat(r.amount) || 0), 0);

  const handleSubmitAll = (e: React.FormEvent) => {
    e.preventDefault();

    const validRows = rows.filter((r) => r.title.trim() && parseFloat(r.amount) > 0);

    if (validRows.length === 0) return;

    const newExpenseBatch: Omit<Expense, "id">[] = validRows.map((r) => ({
      title: r.title.trim(),
      amount: parseFloat(r.amount),
      category: r.category,
      date: date,
      paymentMethod: r.paymentMethod,
      merchantName: r.merchantName || r.title.trim(),
      priority: "Medium" as ExpensePriority,
      tags: [r.category, "Daily Batch"],
      wallet: r.wallet,
      notes: `Batch added for ${date}`,
      currency: selectedCurrency,
    }));

    addBulkExpenses(newExpenseBatch);
    onClose();
  };

  const handleApplyPreset = (presetName: string) => {
    if (presetName === "workday") {
      setRows([
        { id: "p-1", title: "Morning Tea & Breakfast", category: "Dining & Food", amount: "80", paymentMethod: "UPI", wallet: "personal" },
        { id: "p-2", title: "Metro / Auto Fare", category: "Transport & Fuel", amount: "120", paymentMethod: "UPI", wallet: "personal" },
        { id: "p-3", title: "Team Lunch", category: "Dining & Food", amount: "250", paymentMethod: "UPI", wallet: "personal" },
        { id: "p-4", title: "Evening Snacks", category: "Dining & Food", amount: "60", paymentMethod: "UPI", wallet: "personal" },
      ]);
    } else if (presetName === "weekend") {
      setRows([
        { id: "p-1", title: "Weekend Supermarket Groceries", category: "Groceries", amount: "1800", paymentMethod: "Credit Card", wallet: "personal" },
        { id: "p-2", title: "Movie Tickets & Snacks", category: "Other", amount: "750", paymentMethod: "UPI", wallet: "personal" },
        { id: "p-3", title: "Dinner Outing", category: "Dining & Food", amount: "1200", paymentMethod: "Credit Card", wallet: "personal" },
      ]);
    } else if (presetName === "commute_groceries") {
      setRows([
        { id: "p-1", title: "Vehicle Petrol Fill-up", category: "Transport & Fuel", amount: "500", paymentMethod: "UPI", wallet: "personal" },
        { id: "p-2", title: "Daily Milk & Vegetables", category: "Groceries", amount: "320", paymentMethod: "UPI", wallet: "personal" },
      ]);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-3 sm:p-4 overflow-y-auto">
      <div className="w-full max-w-4xl rounded-3xl border border-white/10 bg-neutral-950 p-5 sm:p-7 shadow-2xl space-y-5 my-6 max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[10px] font-mono uppercase tracking-wider font-bold flex items-center gap-1">
                <Zap className="h-3 w-3" />
                Daily Batch Mode
              </span>
              <h2 className="text-xl font-bold text-white tracking-tight">
                Add Day's Expenses Together
              </h2>
            </div>
            <p className="text-xs text-neutral-400 mt-1">
              Log all your daily expenditures for a specific date in one single screen
            </p>
          </div>

          <button
            onClick={onClose}
            className="self-end sm:self-center p-2 rounded-xl border border-white/10 text-neutral-400 hover:text-white hover:bg-white/5 transition-colors cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Date Selector & Total Summary Bar */}
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-4 items-center bg-white/5 border border-white/10 p-4 rounded-2xl">
          <div className="sm:col-span-5 flex items-center gap-3">
            <Calendar className="h-5 w-5 text-emerald-400 shrink-0" />
            <div className="w-full">
              <label className="block text-[10px] font-mono text-neutral-400 uppercase tracking-wider mb-0.5 font-semibold">
                Select Expense Date
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full bg-neutral-900 border border-white/15 rounded-xl px-3 py-1.5 text-xs text-white font-mono font-bold focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          <div className="sm:col-span-7 flex items-center justify-between sm:justify-end gap-6 border-t sm:border-t-0 border-white/10 pt-3 sm:pt-0">
            <div className="text-right">
              <p className="text-[10px] font-mono text-neutral-400 uppercase tracking-widest font-bold">
                Total Day Expenses
              </p>
              <p className="text-2xl font-extrabold font-mono text-emerald-400 tracking-tight">
                {formatCurrency(calculatedTotal)}
              </p>
            </div>
            <div className="text-right pl-4 border-l border-white/10">
              <p className="text-[10px] font-mono text-neutral-400 uppercase tracking-widest font-bold">
                Line Items
              </p>
              <p className="text-2xl font-bold font-mono text-white">
                {rows.length} <span className="text-xs font-normal text-neutral-400">items</span>
              </p>
            </div>
          </div>
        </div>

        {/* Tabs & Quick Presets */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-1 bg-white/5 p-1 rounded-xl border border-white/10 self-start">
            <button
              onClick={() => setActiveTab("table")}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                activeTab === "table"
                  ? "bg-white text-black shadow-md"
                  : "text-neutral-400 hover:text-white"
              }`}
            >
              <ListPlus className="h-3.5 w-3.5" />
              Multi-Item Grid
            </button>
            <button
              onClick={() => setActiveTab("quicktext")}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                activeTab === "quicktext"
                  ? "bg-white text-black shadow-md"
                  : "text-neutral-400 hover:text-white"
              }`}
            >
              <FileText className="h-3.5 w-3.5" />
              Quick Text Parser
            </button>
          </div>

          {/* Quick Day Presets */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
            <span className="text-[10px] font-mono text-neutral-400 font-bold uppercase shrink-0">
              Quick Templates:
            </span>
            <button
              onClick={() => handleApplyPreset("workday")}
              className="px-2.5 py-1 rounded-lg bg-neutral-900 border border-white/10 text-neutral-300 hover:text-white hover:border-emerald-500/50 text-[11px] font-medium transition-all shrink-0 cursor-pointer"
            >
              ☕ Workday Routine
            </button>
            <button
              onClick={() => handleApplyPreset("commute_groceries")}
              className="px-2.5 py-1 rounded-lg bg-neutral-900 border border-white/10 text-neutral-300 hover:text-white hover:border-emerald-500/50 text-[11px] font-medium transition-all shrink-0 cursor-pointer"
            >
              ⛽ Fuel & Groceries
            </button>
            <button
              onClick={() => handleApplyPreset("weekend")}
              className="px-2.5 py-1 rounded-lg bg-neutral-900 border border-white/10 text-neutral-300 hover:text-white hover:border-emerald-500/50 text-[11px] font-medium transition-all shrink-0 cursor-pointer"
            >
              🛍️ Weekend Outing
            </button>
          </div>
        </div>

        {/* Tab 1: Multi-Item Grid */}
        {activeTab === "table" ? (
          <form onSubmit={handleSubmitAll} className="space-y-4">
            <div className="space-y-2.5 max-h-[42vh] overflow-y-auto pr-1">
              {rows.map((row, index) => (
                <div
                  key={row.id}
                  className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 p-3 rounded-2xl bg-white/5 border border-white/10 hover:border-white/20 transition-all items-center"
                >
                  {/* Row index badge */}
                  <div className="hidden sm:flex col-span-1 items-center justify-center">
                    <span className="w-6 h-6 rounded-full bg-white/10 font-mono text-[10px] font-bold text-neutral-400 flex items-center justify-center">
                      {index + 1}
                    </span>
                  </div>

                  {/* Title */}
                  <div className="sm:col-span-4">
                    <input
                      type="text"
                      required
                      placeholder={`Expense item ${index + 1} (e.g. Lunch, Auto fare)`}
                      value={row.title}
                      onChange={(e) => handleRowChange(row.id, "title", e.target.value)}
                      className="w-full bg-neutral-950 border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500"
                    />
                  </div>

                  {/* Category */}
                  <div className="sm:col-span-3">
                    <select
                      value={row.category}
                      onChange={(e) => handleRowChange(row.id, "category", e.target.value as CategoryType)}
                      className="w-full bg-neutral-900 border border-white/10 rounded-xl px-2.5 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                    >
                      {CATEGORY_OPTIONS.map((cat) => (
                        <option key={cat} value={cat}>
                          {cat}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Amount */}
                  <div className="sm:col-span-2 relative">
                    <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-neutral-500 font-mono text-xs font-bold">
                      {currSymbol}
                    </span>
                    <input
                      type="number"
                      step="0.01"
                      required
                      placeholder="0.00"
                      value={row.amount}
                      onChange={(e) => handleRowChange(row.id, "amount", e.target.value)}
                      className="w-full bg-neutral-950 border border-white/10 rounded-xl pl-6 pr-2 py-2 text-xs text-white font-mono font-bold focus:outline-none focus:border-emerald-500"
                    />
                  </div>

                  {/* Payment Method */}
                  <div className="sm:col-span-2 flex items-center gap-2">
                    <select
                      value={row.paymentMethod}
                      onChange={(e) => handleRowChange(row.id, "paymentMethod", e.target.value as PaymentMethod)}
                      className="w-full bg-neutral-900 border border-white/10 rounded-xl px-2 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                    >
                      {PAYMENT_METHODS.map((pm) => (
                        <option key={pm} value={pm}>
                          {pm}
                        </option>
                      ))}
                    </select>

                    <button
                      type="button"
                      onClick={() => handleRemoveRow(row.id)}
                      disabled={rows.length <= 1}
                      className="p-2 rounded-xl text-neutral-500 hover:text-rose-400 hover:bg-rose-500/10 transition-colors disabled:opacity-30 cursor-pointer shrink-0"
                      title="Remove Row"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Bottom Actions inside table tab */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
              <button
                type="button"
                onClick={handleAddRow}
                className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border border-dashed border-white/20 text-emerald-400 hover:bg-emerald-500/10 hover:border-emerald-500/40 text-xs font-semibold transition-all cursor-pointer"
              >
                <Plus className="h-4 w-4" />
                Add Another Expense Line Item
              </button>

              <div className="flex items-center gap-3 w-full sm:w-auto">
                <button
                  type="button"
                  onClick={onClose}
                  className="flex-1 sm:flex-initial px-5 py-2.5 rounded-xl border border-white/10 text-neutral-400 hover:bg-white/5 font-semibold text-xs cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 sm:flex-initial flex items-center justify-center gap-2 px-6 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-xs rounded-xl shadow-lg transition-colors cursor-pointer"
                >
                  <CheckCircle2 className="h-4 w-4" />
                  Save All Day's Expenses ({rows.length})
                </button>
              </div>
            </div>
          </form>
        ) : (
          /* Tab 2: Quick Text Parser */
          <div className="space-y-4">
            <div className="p-4 bg-white/5 border border-white/10 rounded-2xl space-y-2">
              <div className="flex items-center gap-2 text-xs font-bold text-white">
                <Sparkles className="h-4 w-4 text-emerald-400" />
                Type or Paste Multiple Line Items:
              </div>
              <p className="text-[11px] text-neutral-400">
                Write one item per line using format: <span className="font-mono text-emerald-400">[Title] [Amount] [PaymentMethod]</span>
              </p>
              <textarea
                rows={6}
                value={rawText}
                onChange={(e) => setRawText(e.target.value)}
                placeholder={`Example:\nMorning Tea 30 UPI\nLunch Meal 180 Cash\nGroceries Store 450 Credit Card`}
                className="w-full bg-neutral-950 border border-white/15 rounded-xl p-3 text-xs text-white font-mono focus:outline-none focus:border-emerald-500 resize-none"
              />
            </div>

            <div className="flex justify-end gap-3 pt-1">
              <button
                type="button"
                onClick={() => setActiveTab("table")}
                className="px-4 py-2 rounded-xl border border-white/10 text-neutral-400 hover:bg-white/5 text-xs font-semibold cursor-pointer"
              >
                Back to Grid
              </button>
              <button
                type="button"
                onClick={parseQuickText}
                className="flex items-center gap-2 px-5 py-2 bg-emerald-500 hover:bg-emerald-400 text-black font-bold text-xs rounded-xl transition-colors cursor-pointer"
              >
                <ArrowRight className="h-4 w-4" />
                Parse into Grid & Calculate
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
