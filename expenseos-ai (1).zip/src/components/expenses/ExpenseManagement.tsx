import React, { useState } from "react";
import { useExpenseOS } from "../../context/ExpenseContext";
import { Expense, CategoryType, PaymentMethod, ExpensePriority, WalletType } from "../../types";
import { CURRENCIES } from "../../data/mockData";
import {
  Search,
  Plus,
  Trash2,
  Copy,
  Edit2,
  Calendar,
  DollarSign,
  Download,
  Filter,
  CheckCircle2,
  PieChart as PieChartIcon,
  Tag,
  Camera,
  Mic,
  X,
  Zap,
} from "lucide-react";
import { AIReceiptScannerModal } from "./AIReceiptScannerModal";
import { VoiceEntryModal } from "./VoiceEntryModal";
import { DailyBatchExpenseModal } from "./DailyBatchExpenseModal";

export const ExpenseManagement: React.FC = () => {
  const {
    expenses,
    addExpense,
    editExpense,
    deleteExpense,
    duplicateExpense,
    bulkDeleteExpenses,
    formatCurrency,
    selectedCurrency,
  } = useExpenseOS();

  const currSymbol = CURRENCIES[selectedCurrency]?.symbol || "₹";

  // Local Controls State
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<string>("All");
  const [walletFilter, setWalletFilter] = useState<string>("All");
  const [priorityFilter, setPriorityFilter] = useState<string>("All");
  const [sortBy, setSortBy] = useState<"date" | "amount" | "title">("date");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("desc");

  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isDailyBatchModalOpen, setIsDailyBatchModalOpen] = useState(false);
  const [isOcrModalOpen, setIsOcrModalOpen] = useState(false);
  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);

  // Form State
  const [formTitle, setFormTitle] = useState("");
  const [formAmount, setFormAmount] = useState("");
  const [formCategory, setFormCategory] = useState<CategoryType>("Groceries");
  const [formDate, setFormDate] = useState(new Date().toISOString().split("T")[0]);
  const [formPaymentMethod, setFormPaymentMethod] = useState<PaymentMethod>("Credit Card");
  const [formMerchant, setFormMerchant] = useState("");
  const [formPriority, setFormPriority] = useState<ExpensePriority>("Medium");
  const [formTags, setFormTags] = useState("Groceries, Health");
  const [formWallet, setFormWallet] = useState<WalletType>("personal");
  const [formNotes, setFormNotes] = useState("");

  const resetForm = () => {
    setFormTitle("");
    setFormAmount("");
    setFormCategory("Groceries");
    setFormDate(new Date().toISOString().split("T")[0]);
    setFormPaymentMethod("Credit Card");
    setFormMerchant("");
    setFormPriority("Medium");
    setFormTags("Groceries, Health");
    setFormWallet("personal");
    setFormNotes("");
    setEditingExpense(null);
  };

  const handleOpenEdit = (exp: Expense) => {
    setEditingExpense(exp);
    setFormTitle(exp.title);
    setFormAmount(String(exp.amount));
    setFormCategory(exp.category);
    setFormDate(exp.date);
    setFormPaymentMethod(exp.paymentMethod);
    setFormMerchant(exp.merchantName || "");
    setFormPriority(exp.priority);
    setFormTags(exp.tags ? exp.tags.join(", ") : "");
    setFormWallet(exp.wallet);
    setFormNotes(exp.notes || "");
    setIsAddModalOpen(true);
  };

  const handleSubmitForm = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedAmount = parseFloat(formAmount) || 0;
    const tagArray = formTags.split(",").map((t) => t.trim()).filter(Boolean);

    if (editingExpense) {
      editExpense(editingExpense.id, {
        title: formTitle,
        amount: parsedAmount,
        category: formCategory,
        date: formDate,
        paymentMethod: formPaymentMethod,
        merchantName: formMerchant || formTitle,
        priority: formPriority,
        tags: tagArray,
        wallet: formWallet,
        notes: formNotes,
      });
    } else {
      addExpense({
        title: formTitle,
        amount: parsedAmount,
        category: formCategory,
        date: formDate,
        paymentMethod: formPaymentMethod,
        merchantName: formMerchant || formTitle,
        priority: formPriority,
        tags: tagArray,
        wallet: formWallet,
        notes: formNotes,
        currency: selectedCurrency,
      });
    }

    setIsAddModalOpen(false);
    resetForm();
  };

  const handleAiAutoFill = (parsed: any) => {
    setFormTitle(parsed.title || `Purchase at ${parsed.merchant || "Merchant"}`);
    setFormAmount(String(parsed.totalAmount || parsed.amount || "0"));
    setFormCategory(parsed.category || "Groceries");
    setFormDate(parsed.date || new Date().toISOString().split("T")[0]);
    setFormMerchant(parsed.merchant || parsed.merchantName || "");
    setFormPaymentMethod(parsed.paymentMethod || "Credit Card");
    setFormNotes(parsed.notes || "Auto-extracted via AI Scanner");
    setIsAddModalOpen(true);
  };

  // Filter & Sort Expenses
  const filtered = expenses.filter((e) => {
    const matchSearch =
      e.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (e.merchantName && e.merchantName.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (e.tags && e.tags.some((t) => t.toLowerCase().includes(searchTerm.toLowerCase())));

    const matchCategory = categoryFilter === "All" || e.category === categoryFilter;
    const matchWallet = walletFilter === "All" || e.wallet === walletFilter;
    const matchPriority = priorityFilter === "All" || e.priority === priorityFilter;

    return matchSearch && matchCategory && matchWallet && matchPriority;
  });

  const sorted = [...filtered].sort((a, b) => {
    if (sortBy === "amount") {
      return sortOrder === "desc" ? b.amount - a.amount : a.amount - b.amount;
    } else if (sortBy === "title") {
      return sortOrder === "desc" ? b.title.localeCompare(a.title) : a.title.localeCompare(b.title);
    } else {
      return sortOrder === "desc" ? b.date.localeCompare(a.date) : a.date.localeCompare(b.date);
    }
  });

  // Calculate expense metrics
  const totalFilteredExpense = sorted.reduce((sum, e) => sum + e.amount, 0);
  const averageExpense = sorted.length > 0 ? totalFilteredExpense / sorted.length : 0;
  const maxExpense = sorted.length > 0 ? Math.max(...sorted.map((e) => e.amount)) : 0;

  const exportCSV = () => {
    const headers = ["ID,Title,Amount,Category,Date,Merchant,PaymentMethod,Wallet,Priority,Tags\n"];
    const rows = sorted.map(
      (e) => `"${e.id}","${e.title}",${e.amount},"${e.category}","${e.date}","${e.merchantName || ""}","${e.paymentMethod}","${e.wallet}","${e.priority}","${(e.tags || []).join(";")}"`
    );
    const blob = new Blob([headers.concat(rows).join("\n")], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `ExpenseOS_Report_${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
  };

  const toggleSelectAll = () => {
    if (selectedIds.length === sorted.length) setSelectedIds([]);
    else setSelectedIds(sorted.map((e) => e.id));
  };

  const toggleSelectOne = (id: string) => {
    if (selectedIds.includes(id)) setSelectedIds(selectedIds.filter((x) => x !== id));
    else setSelectedIds([...selectedIds, id]);
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-light text-white tracking-tight">
            Expense <span className="font-bold">Manager & Calculator</span>
          </h1>
          <p className="text-xs sm:text-sm text-neutral-400 mt-1">
            Track, edit, filter and calculate your monthly expenditures
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setIsDailyBatchModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 font-bold text-xs transition-all cursor-pointer shadow-lg shadow-emerald-500/5"
          >
            <Zap className="h-4 w-4" />
            Add Day's Expenses (Batch)
          </button>

          <button
            onClick={() => setIsOcrModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 border border-white/10 text-white font-medium text-xs cursor-pointer"
          >
            <Camera className="h-4 w-4 text-emerald-400" />
            Scan Receipt
          </button>

          <button
            onClick={() => setIsVoiceModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-white/10 hover:bg-white/15 border border-white/10 text-white font-medium text-xs cursor-pointer"
          >
            <Mic className="h-4 w-4 text-blue-400" />
            Voice Entry
          </button>

          <button
            onClick={() => {
              resetForm();
              setIsAddModalOpen(true);
            }}
            className="flex items-center gap-2 px-4 py-2.5 bg-white text-black font-semibold text-xs rounded-xl hover:bg-neutral-200 transition-colors shadow-lg cursor-pointer"
          >
            <Plus className="h-4 w-4" />
            Add Single
          </button>
        </div>
      </div>

      {/* Calculated Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 bg-neutral-950/60 border border-white/10 rounded-2xl backdrop-blur-xl">
          <p className="text-neutral-400 text-[10px] font-mono uppercase tracking-widest font-bold mb-1">Total Calculated Expenses</p>
          <p className="text-2xl font-bold text-white font-mono tracking-tight">{formatCurrency(totalFilteredExpense)}</p>
          <p className="text-[10px] text-neutral-500 mt-1 font-mono">{sorted.length} matching transactions logged</p>
        </div>

        <div className="p-5 bg-neutral-950/60 border border-white/10 rounded-2xl backdrop-blur-xl">
          <p className="text-neutral-400 text-[10px] font-mono uppercase tracking-widest font-bold mb-1">Average Per Item</p>
          <p className="text-2xl font-bold text-emerald-400 font-mono tracking-tight">{formatCurrency(averageExpense)}</p>
          <p className="text-[10px] text-neutral-500 mt-1 font-mono">Calculated average transaction cost</p>
        </div>

        <div className="p-5 bg-neutral-950/60 border border-white/10 rounded-2xl backdrop-blur-xl">
          <p className="text-neutral-400 text-[10px] font-mono uppercase tracking-widest font-bold mb-1">Highest Expense</p>
          <p className="text-2xl font-bold text-rose-400 font-mono tracking-tight">{formatCurrency(maxExpense)}</p>
          <p className="text-[10px] text-neutral-500 mt-1 font-mono">Single largest outflow item</p>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="bg-neutral-950/60 border border-white/10 rounded-2xl p-4 backdrop-blur-xl space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {/* Search Box */}
          <div className="relative lg:col-span-2">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-neutral-500" />
            <input
              type="text"
              placeholder="Search by title, merchant, or tag..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* Category Filter */}
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="bg-neutral-900 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
          >
            <option value="All">All Categories</option>
            <option value="Groceries">Groceries</option>
            <option value="Dining & Food">Dining & Food</option>
            <option value="Electronics">Electronics</option>
            <option value="Subscriptions">Subscriptions</option>
            <option value="Transport & Fuel">Transport & Fuel</option>
            <option value="Investment">Investment</option>
            <option value="Healthcare">Healthcare</option>
            <option value="Utilities">Utilities</option>
          </select>

          {/* Priority Filter */}
          <select
            value={priorityFilter}
            onChange={(e) => setPriorityFilter(e.target.value)}
            className="bg-neutral-900 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
          >
            <option value="All">All Priorities</option>
            <option value="High">High Priority</option>
            <option value="Medium">Medium Priority</option>
            <option value="Low">Low Priority</option>
          </select>

          {/* Sort By */}
          <select
            value={`${sortBy}-${sortOrder}`}
            onChange={(e) => {
              const [sb, so] = e.target.value.split("-") as [any, any];
              setSortBy(sb);
              setSortOrder(so);
            }}
            className="bg-neutral-900 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
          >
            <option value="date-desc">Newest Date</option>
            <option value="date-asc">Oldest Date</option>
            <option value="amount-desc">Highest Expense</option>
            <option value="amount-asc">Lowest Expense</option>
          </select>
        </div>

        {/* Selection & Export actions */}
        <div className="flex flex-wrap items-center justify-between pt-2 border-t border-white/5 text-xs text-neutral-400">
          <div className="flex items-center gap-3">
            <button
              onClick={toggleSelectAll}
              className="text-neutral-400 hover:text-white transition-colors cursor-pointer"
            >
              {selectedIds.length === sorted.length && sorted.length > 0 ? "Deselect All" : "Select All"}
            </button>
            {selectedIds.length > 0 && (
              <button
                onClick={() => {
                  bulkDeleteExpenses(selectedIds);
                  setSelectedIds([]);
                }}
                className="text-rose-400 font-bold hover:underline cursor-pointer flex items-center gap-1"
              >
                <Trash2 className="h-3.5 w-3.5" />
                Delete Selected ({selectedIds.length})
              </button>
            )}
          </div>

          <button
            onClick={exportCSV}
            className="flex items-center gap-1 text-neutral-300 hover:text-white transition-colors cursor-pointer"
          >
            <Download className="h-3.5 w-3.5" />
            Export CSV Report
          </button>
        </div>
      </div>

      {/* Expenses Table / List */}
      <div className="bg-neutral-950/60 border border-white/10 rounded-3xl backdrop-blur-xl overflow-hidden shadow-xl">
        <div className="divide-y divide-white/5">
          {sorted.length === 0 ? (
            <div className="p-12 text-center text-neutral-500 text-xs font-mono">
              No matching expense items found. Click "+ Add Expense" to record a new transaction.
            </div>
          ) : (
            sorted.map((exp) => (
              <div
                key={exp.id}
                className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-white/5 transition-all text-xs"
              >
                <div className="flex items-center gap-3">
                  <input
                    type="checkbox"
                    checked={selectedIds.includes(exp.id)}
                    onChange={() => toggleSelectOne(exp.id)}
                    className="rounded border-white/20 bg-neutral-900 text-emerald-500 focus:ring-0 cursor-pointer"
                  />
                  <div className="w-10 h-10 rounded-xl bg-neutral-800 border border-white/10 flex items-center justify-center font-bold text-white">
                    {exp.title.charAt(0)}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="font-bold text-white text-sm">{exp.title}</p>
                      <span className="px-2 py-0.5 rounded-md bg-white/5 text-[10px] font-mono text-neutral-400 border border-white/10">
                        {exp.category}
                      </span>
                    </div>
                    <p className="text-[10px] font-mono text-neutral-500 mt-0.5">
                      {exp.merchantName || exp.title} • {exp.date} • {exp.paymentMethod}
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between sm:justify-end gap-4 pl-7 sm:pl-0">
                  <span className="font-mono font-extrabold text-white text-base">
                    -{formatCurrency(exp.amount)}
                  </span>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleOpenEdit(exp)}
                      className="p-2 rounded-lg text-neutral-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
                      title="Edit Expense"
                    >
                      <Edit2 className="h-3.5 w-3.5" />
                    </button>
                    <button
                      onClick={() => duplicateExpense(exp.id)}
                      className="p-2 rounded-lg text-neutral-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
                      title="Duplicate Expense"
                    >
                      <Copy className="h-3.5 w-3.5" />
                    </button>
                    <button
                      onClick={() => deleteExpense(exp.id)}
                      className="p-2 rounded-lg text-neutral-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors cursor-pointer"
                      title="Delete Expense"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Add / Edit Expense Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <div className="w-full max-w-lg rounded-3xl border border-white/10 bg-neutral-950 p-6 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h3 className="text-lg font-bold text-white">
                {editingExpense ? "Edit Expense Item" : "Record Expense"}
              </h3>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="text-neutral-500 hover:text-white cursor-pointer"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitForm} className="space-y-4 text-xs">
              <div>
                <label className="block text-neutral-400 font-mono text-[10px] uppercase tracking-wider mb-1">
                  Expense Title *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Monthly Grocery Shopping"
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  className="w-full rounded-xl border border-white/10 bg-white/5 px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-neutral-400 font-mono text-[10px] uppercase tracking-wider mb-1">
                    Amount ({currSymbol}) *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    required
                    placeholder="125.50"
                    value={formAmount}
                    onChange={(e) => setFormAmount(e.target.value)}
                    className="w-full rounded-xl border border-white/10 bg-white/5 px-3 py-2.5 text-white font-mono font-bold focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-neutral-400 font-mono text-[10px] uppercase tracking-wider mb-1">
                    Date *
                  </label>
                  <input
                    type="date"
                    required
                    value={formDate}
                    onChange={(e) => setFormDate(e.target.value)}
                    className="w-full rounded-xl border border-white/10 bg-neutral-900 px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-neutral-400 font-mono text-[10px] uppercase tracking-wider mb-1">
                    Category
                  </label>
                  <select
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value as CategoryType)}
                    className="w-full rounded-xl border border-white/10 bg-neutral-900 px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500"
                  >
                    <option value="Groceries">Groceries</option>
                    <option value="Dining & Food">Dining & Food</option>
                    <option value="Electronics">Electronics</option>
                    <option value="Subscriptions">Subscriptions</option>
                    <option value="Transport & Fuel">Transport & Fuel</option>
                    <option value="Investment">Investment</option>
                    <option value="Healthcare">Healthcare</option>
                    <option value="Utilities">Utilities</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block text-neutral-400 font-mono text-[10px] uppercase tracking-wider mb-1">
                    Payment Method
                  </label>
                  <select
                    value={formPaymentMethod}
                    onChange={(e) => setFormPaymentMethod(e.target.value as PaymentMethod)}
                    className="w-full rounded-xl border border-white/10 bg-neutral-900 px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500"
                  >
                    <option value="Credit Card">Credit Card</option>
                    <option value="Debit Card">Debit Card</option>
                    <option value="Cash">Cash</option>
                    <option value="Bank Transfer">Bank Transfer</option>
                    <option value="Crypto">Crypto</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-neutral-400 font-mono text-[10px] uppercase tracking-wider mb-1">
                  Merchant / Vendor Name
                </label>
                <input
                  type="text"
                  placeholder="e.g. Whole Foods Market"
                  value={formMerchant}
                  onChange={(e) => setFormMerchant(e.target.value)}
                  className="w-full rounded-xl border border-white/10 bg-white/5 px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-neutral-400 font-mono text-[10px] uppercase tracking-wider mb-1">
                  Notes / Details
                </label>
                <textarea
                  rows={2}
                  placeholder="Optional transaction details..."
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  className="w-full rounded-xl border border-white/10 bg-white/5 px-3 py-2.5 text-white focus:outline-none focus:border-emerald-500 resize-none"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="flex-1 rounded-xl border border-white/10 py-2.5 font-bold text-neutral-400 hover:bg-white/5 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 rounded-xl bg-white hover:bg-neutral-200 font-bold text-black py-2.5 transition-colors cursor-pointer"
                >
                  {editingExpense ? "Save Changes" : "Record Expense"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* AI Scanners */}
      <AIReceiptScannerModal
        isOpen={isOcrModalOpen}
        onClose={() => setIsOcrModalOpen(false)}
        onApplyParsedData={handleAiAutoFill}
      />

      <VoiceEntryModal
        isOpen={isVoiceModalOpen}
        onClose={() => setIsVoiceModalOpen(false)}
        onApplyParsedData={handleAiAutoFill}
      />

      <DailyBatchExpenseModal
        isOpen={isDailyBatchModalOpen}
        onClose={() => setIsDailyBatchModalOpen(false)}
      />
    </div>
  );
};
