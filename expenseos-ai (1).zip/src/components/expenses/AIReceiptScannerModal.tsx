import React, { useState } from "react";
import { useExpenseOS } from "../../context/ExpenseContext";
import { X, Sparkles, Camera, Upload, CheckCircle2, Loader2, FileText, AlertCircle } from "lucide-react";

interface AIReceiptScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onReceiptParsed: (parsedData: any) => void;
}

export const AIReceiptScannerModal: React.FC<AIReceiptScannerModalProps> = ({
  isOpen,
  onClose,
  onReceiptParsed,
}) => {
  const { addNotification } = useExpenseOS();

  const [loading, setLoading] = useState(false);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [extractedData, setExtractedData] = useState<any | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewImage(reader.result as string);
        setExtractedData(null);
        setErrorMsg(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleScanReceipt = async () => {
    if (!previewImage) return;
    setLoading(true);
    setErrorMsg(null);

    try {
      const res = await fetch("/api/ai/receipt-scan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ imageBase64: previewImage }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.details || "Failed to scan receipt");
      }

      setExtractedData(data);
      addNotification("Receipt Scanned!", `Extracted receipt from ${data.merchant || "Merchant"} ($${data.totalAmount})`, "success");
    } catch (err: any) {
      console.error("Scan error:", err);
      setErrorMsg(err?.message || "An error occurred while scanning with Gemini Vision.");
    } finally {
      setLoading(false);
    }
  };

  const handleConfirmAndAdd = () => {
    if (extractedData) {
      onReceiptParsed(extractedData);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-2xl overflow-hidden max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute right-4 top-4 p-2 rounded-full text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
        >
          <X className="h-5 w-5" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-gradient-to-tr from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-500/30">
            <Sparkles className="h-5 w-5 animate-pulse" />
          </div>
          <div>
            <h3 className="text-lg font-extrabold text-slate-900 dark:text-white">
              Gemini Vision AI Receipt Scanner
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Extract merchant, line items, date, GST, and totals automatically
            </p>
          </div>
        </div>

        {/* Upload or Drop Area */}
        {!previewImage ? (
          <label className="flex flex-col items-center justify-center h-56 rounded-2xl border-2 border-dashed border-indigo-300 dark:border-indigo-800/60 bg-indigo-50/50 dark:bg-indigo-950/20 hover:bg-indigo-100/50 dark:hover:bg-indigo-950/40 cursor-pointer transition-all">
            <div className="flex flex-col items-center justify-center pt-5 pb-6">
              <Upload className="h-10 w-10 text-indigo-500 mb-2 animate-bounce" />
              <p className="mb-1 text-xs font-bold text-slate-800 dark:text-slate-200">
                Click to upload or drag receipt photo
              </p>
              <p className="text-[10px] text-slate-400">PNG, JPG, WEBP up to 10MB</p>
            </div>
            <input type="file" accept="image/*" onChange={handleFileChange} className="hidden" />
          </label>
        ) : (
          <div className="space-y-4">
            <div className="relative h-48 w-full rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-black flex items-center justify-center">
              <img src={previewImage} alt="Receipt Preview" className="h-full object-contain" />
              <button
                onClick={() => setPreviewImage(null)}
                className="absolute top-2 right-2 px-3 py-1 rounded-lg bg-black/70 text-white text-xs font-bold hover:bg-rose-600"
              >
                Change Image
              </button>
            </div>

            {!extractedData && (
              <button
                onClick={handleScanReceipt}
                disabled={loading}
                className="flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-indigo-600 via-purple-600 to-cyan-600 py-3 text-xs font-bold text-white shadow-lg shadow-indigo-500/25 hover:opacity-95 cursor-pointer disabled:opacity-50"
              >
                {loading ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span>Gemini AI Analyzing OCR Text...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="h-4 w-4" />
                    <span>Extract Expense Details with AI</span>
                  </>
                )}
              </button>
            )}
          </div>
        )}

        {errorMsg && (
          <div className="mt-4 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 text-rose-600 dark:text-rose-400 text-xs flex items-center gap-2">
            <AlertCircle className="h-4 w-4 flex-shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Extracted Data Preview & Auto-fill Confirmation */}
        {extractedData && (
          <div className="mt-6 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/60 space-y-3 animate-in fade-in">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-700 pb-2">
              <span className="text-xs font-bold text-indigo-600 dark:text-cyan-400 flex items-center gap-1.5">
                <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                OCR Extraction Successful ({extractedData.confidenceScore || 98}% Confidence)
              </span>
              <span className="text-xs font-extrabold text-slate-900 dark:text-white">
                ${extractedData.totalAmount}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>
                <span className="text-[10px] text-slate-400 block">MERCHANT</span>
                <span className="font-bold text-slate-800 dark:text-slate-200">{extractedData.merchant}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block">CATEGORY</span>
                <span className="font-bold text-slate-800 dark:text-slate-200">{extractedData.category}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block">DATE</span>
                <span className="font-bold text-slate-800 dark:text-slate-200">{extractedData.date}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block">GST / TAX</span>
                <span className="font-bold text-slate-800 dark:text-slate-200">${extractedData.gst || 0}</span>
              </div>
            </div>

            {extractedData.items && extractedData.items.length > 0 && (
              <div className="pt-2 border-t border-slate-200 dark:border-slate-700">
                <p className="text-[10px] font-bold text-slate-400 mb-1">LINE ITEMS DETECTED:</p>
                <div className="space-y-1 max-h-28 overflow-y-auto">
                  {extractedData.items.map((it: any, idx: number) => (
                    <div key={idx} className="flex justify-between text-[11px]">
                      <span className="text-slate-600 dark:text-slate-300">{it.name} (x{it.quantity || 1})</span>
                      <span className="font-mono text-slate-900 dark:text-white">${it.price}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <button
              onClick={handleConfirmAndAdd}
              className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 py-2.5 text-xs font-bold text-white shadow-md shadow-emerald-500/20 cursor-pointer"
            >
              <CheckCircle2 className="h-4 w-4" />
              Auto-Fill Expense Form
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
