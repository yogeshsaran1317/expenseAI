import React from "react";
import { useExpenseOS } from "../../context/ExpenseContext";
import { Bell, CheckCheck, Trash2, AlertTriangle, CheckCircle, Info, AlertCircle } from "lucide-react";

interface NotificationsPopoverProps {
  onClose: () => void;
}

export const NotificationsPopover: React.FC<NotificationsPopoverProps> = ({ onClose }) => {
  const { notifications, markNotificationRead, clearAllNotifications, setActiveTab } = useExpenseOS();

  const getIcon = (type: string) => {
    switch (type) {
      case "alert":
      case "warning":
        return <AlertTriangle className="h-4 w-4 text-amber-500" />;
      case "success":
        return <CheckCircle className="h-4 w-4 text-emerald-500" />;
      default:
        return <Info className="h-4 w-4 text-indigo-500" />;
    }
  };

  return (
    <div className="absolute right-0 mt-2 w-80 sm:w-96 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3 shadow-2xl z-50 animate-in fade-in zoom-in-95 duration-150">
      <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-2">
          <Bell className="h-4 w-4 text-indigo-500" />
          <h4 className="font-bold text-xs text-slate-900 dark:text-white">Notifications</h4>
          <span className="rounded-full bg-indigo-100 dark:bg-indigo-950 px-2 py-0.5 text-[10px] font-bold text-indigo-600 dark:text-indigo-400">
            {notifications.length}
          </span>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={clearAllNotifications}
            className="p-1 text-[11px] font-medium text-slate-400 hover:text-rose-500 transition-colors flex items-center gap-1"
            title="Clear all"
          >
            <Trash2 className="h-3 w-3" />
            Clear
          </button>
        </div>
      </div>

      <div className="max-h-80 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800/60 py-1">
        {notifications.length === 0 ? (
          <div className="py-8 text-center text-xs text-slate-400">
            No active notifications. You are all caught up!
          </div>
        ) : (
          notifications.map((n) => (
            <div
              key={n.id}
              onClick={() => {
                markNotificationRead(n.id);
                if (n.linkTab) setActiveTab(n.linkTab as any);
                onClose();
              }}
              className={`flex items-start gap-3 p-2.5 rounded-xl cursor-pointer transition-colors ${
                n.isRead ? "opacity-70 hover:bg-slate-50 dark:hover:bg-slate-800/40" : "bg-indigo-50/40 dark:bg-indigo-950/30 hover:bg-indigo-50 dark:hover:bg-indigo-900/40"
              }`}
            >
              <div className="mt-0.5">{getIcon(n.type)}</div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <p className="text-xs font-semibold text-slate-900 dark:text-slate-100 truncate">{n.title}</p>
                  <span className="text-[10px] text-slate-400 whitespace-nowrap">{n.timestamp}</span>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-2">{n.message}</p>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
