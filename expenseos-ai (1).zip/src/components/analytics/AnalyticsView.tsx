import React from "react";
import { useExpenseOS } from "../../context/ExpenseContext";
import {
  BarChart3,
  TrendingUp,
  PieChart as PieIcon,
  Activity,
  AlertOctagon,
  Sparkles,
  Zap,
} from "lucide-react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  RadarChart,
  Radar,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

export const AnalyticsView: React.FC = () => {
  const { metrics, expenses, budgets, formatCurrency } = useExpenseOS();

  // Machine Learning Time Series Data
  const timeSeriesForecast = [
    { month: "Jan", actual: 3100, predicted: 3050 },
    { month: "Feb", actual: 3400, predicted: 3350 },
    { month: "Mar", actual: 3200, predicted: 3250 },
    { month: "Apr", actual: 4100, predicted: 3900 },
    { month: "May", actual: 3600, predicted: 3550 },
    { month: "Jun", actual: 3280, predicted: 3300 },
    { month: "Jul (Est)", actual: null, predicted: 3120 },
    { month: "Aug (Est)", actual: null, predicted: 3250 },
    { month: "Sep (Est)", actual: null, predicted: 3180 },
  ];

  // Financial DNA Radar Chart Data
  const radarData = [
    { subject: "Savings Rate", A: 85, fullMark: 100 },
    { subject: "Budget Control", A: 92, fullMark: 100 },
    { subject: "Debt Safety", A: 98, fullMark: 100 },
    { subject: "Investment Ratio", A: 78, fullMark: 100 },
    { subject: "Liquidity Reserve", A: 88, fullMark: 100 },
    { subject: "Tax Efficiency", A: 82, fullMark: 100 },
  ];

  const categoryBarData = budgets.map((b) => ({
    category: b.category.split(" ")[0],
    Spent: b.spent,
    Limit: b.limit,
  }));

  const COLORS = ["#10b981", "#f59e0b", "#6366f1", "#06b6d4", "#ec4899", "#8b5cf6", "#3b82f6"];

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
            <BarChart3 className="h-6 w-6 text-indigo-500" />
            Machine Learning & Predictive Analytics
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Time series forecasting, spending pattern detection, anomaly radar & Financial DNA
          </p>
        </div>

        <div className="rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 p-2 border border-indigo-200 dark:border-indigo-800 text-xs flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-indigo-500" />
          <span className="font-bold text-slate-800 dark:text-slate-200">
            AI DNA Profile: Calculated Accumulator
          </span>
        </div>
      </div>

      {/* Grid: Time Series Forecast + Financial DNA Radar */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Machine Learning Time Series Expense Forecast */}
        <div className="lg:col-span-2 rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-cyan-500" />
                Prophet Time-Series Expense Forecast
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Predicting upcoming 3-month spending with 94.2% ML accuracy
              </p>
            </div>
            <span className="rounded-full bg-cyan-500/10 px-2.5 py-1 text-[10px] font-bold text-cyan-500 border border-cyan-500/20">
              Forecast $3,120 next mo
            </span>
          </div>

          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={timeSeriesForecast} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <XAxis dataKey="month" stroke="#94a3b8" fontSize={11} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#0f172a",
                    borderColor: "#334155",
                    borderRadius: "12px",
                    color: "#fff",
                    fontSize: "12px",
                  }}
                  formatter={(val: any) => (val ? formatCurrency(Number(val)) : "N/A")}
                />
                <Line type="monotone" dataKey="actual" stroke="#10b981" strokeWidth={3} dot={{ r: 4 }} name="Actual Spend" />
                <Line type="monotone" dataKey="predicted" stroke="#6366f1" strokeWidth={3} strokeDasharray="5 5" dot={{ r: 4 }} name="ML Predicted" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Financial DNA Radar Chart */}
        <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-xl flex flex-col justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Activity className="h-5 w-5 text-indigo-500" />
              Financial DNA Radar
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">Multi-axis health diagnostic</p>
          </div>

          <div className="h-64 my-2 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={radarData}>
                <PolarGrid stroke="#334155" />
                <PolarAngleAxis dataKey="subject" stroke="#94a3b8" fontSize={10} />
                <PolarRadiusAxis angle={30} domain={[0, 100]} stroke="#475569" fontSize={9} />
                <Radar name="Your Score" dataKey="A" stroke="#6366f1" fill="#6366f1" fillOpacity={0.4} />
              </RadarChart>
            </ResponsiveContainer>
          </div>

          <div className="text-center p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800 text-xs font-bold text-indigo-600 dark:text-indigo-300">
            Overall Health Score: {metrics.financialHealthScore}/100
          </div>
        </div>
      </div>

      {/* Category Budget Performance Bar Chart */}
      <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <PieIcon className="h-5 w-5 text-amber-500" />
              Category Budget Performance & Variance
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">Actual spent vs allocated category limit</p>
          </div>
        </div>

        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={categoryBarData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <XAxis dataKey="category" stroke="#94a3b8" fontSize={11} tickLine={false} />
              <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#0f172a",
                  borderColor: "#334155",
                  borderRadius: "12px",
                  color: "#fff",
                  fontSize: "12px",
                }}
                formatter={(val: any) => formatCurrency(Number(val))}
              />
              <Bar dataKey="Spent" fill="#10b981" radius={[6, 6, 0, 0]} />
              <Bar dataKey="Limit" fill="#334155" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Machine Learning Anomaly Guard */}
      <div className="rounded-3xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 shadow-xl">
        <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2 mb-2">
          <AlertOctagon className="h-5 w-5 text-rose-500" />
          Machine Learning Anomaly Detection Radar
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
          Automatic outlier detection identifying potential fraud or unexpected spikes
        </p>

        <div className="space-y-3">
          <div className="p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div>
              <span className="font-bold text-rose-700 dark:text-rose-400">Tech Gadget Store • $450.00</span>
              <p className="text-slate-600 dark:text-slate-300 mt-0.5">
                Expense is 240% higher than your standard Electronics category benchmark.
              </p>
            </div>
            <span className="px-3 py-1 rounded-full bg-rose-500 text-white font-bold text-[10px] self-start sm:self-center">
              Outlier Spike
            </span>
          </div>

          <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div>
              <span className="font-bold text-amber-700 dark:text-amber-400">Equinox Gym Pass • $65.00</span>
              <p className="text-slate-600 dark:text-slate-300 mt-0.5">
                Subscription flagged as low utility (0 visits in 30 days).
              </p>
            </div>
            <span className="px-3 py-1 rounded-full bg-amber-500 text-white font-bold text-[10px] self-start sm:self-center">
              Unused Subscription
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
