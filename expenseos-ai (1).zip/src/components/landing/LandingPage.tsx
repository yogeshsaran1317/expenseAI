import React from "react";
import { useExpenseOS } from "../../context/ExpenseContext";
import { Sparkles, ArrowRight, ShieldCheck, Zap, BarChart3, Bot, Lock, CheckCircle2 } from "lucide-react";

export const LandingPage: React.FC<{ onLaunchApp: () => void }> = ({ onLaunchApp }) => {
  return (
    <div className="min-h-screen bg-slate-950 text-white space-y-20 pb-20 overflow-hidden">
      {/* Hero Section */}
      <section className="relative pt-20 pb-16 px-6 text-center max-w-5xl mx-auto">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 h-96 w-96 rounded-full bg-gradient-to-tr from-indigo-600/30 via-purple-600/30 to-cyan-500/30 blur-3xl pointer-events-none"></div>

        <div className="relative z-10 space-y-6">
          <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-1.5 text-xs font-bold text-cyan-400 border border-white/10 backdrop-blur-md">
            <Sparkles className="h-4 w-4" /> ExpenseOS AI v3.0 Released
          </span>

          <h1 className="text-4xl sm:text-6xl font-black tracking-tight leading-tight">
            The Intelligent Personal Finance <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-indigo-400 to-purple-400">
              Operating System
            </span>
          </h1>

          <p className="text-sm sm:text-base text-slate-300 max-w-2xl mx-auto leading-relaxed">
            ExpenseOS AI replaces standard CRUD expense trackers with an autonomous financial CFO. Real-time Gemini Vision OCR receipt scanner, predictive cash flow modeling, and FIRE goal accumulation.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
            <button
              onClick={onLaunchApp}
              className="flex items-center gap-2 rounded-2xl bg-gradient-to-r from-indigo-600 via-purple-600 to-cyan-600 px-8 py-4 text-sm font-extrabold text-white shadow-2xl shadow-indigo-500/40 hover:scale-105 transition-all cursor-pointer"
            >
              <span>Launch Financial OS</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </section>

      {/* Feature Grid */}
      <section className="max-w-6xl mx-auto px-6 grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="p-6 rounded-3xl border border-slate-800 bg-slate-900/60 backdrop-blur-md space-y-3">
          <div className="h-10 w-10 rounded-2xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center">
            <Bot className="h-6 w-6" />
          </div>
          <h3 className="font-extrabold text-base">Gemini Vision OCR</h3>
          <p className="text-xs text-slate-400">Scan paper receipts instantly using camera AI to auto-fill line items, GST taxes, and merchant categories.</p>
        </div>

        <div className="p-6 rounded-3xl border border-slate-800 bg-slate-900/60 backdrop-blur-md space-y-3">
          <div className="h-10 w-10 rounded-2xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center">
            <BarChart3 className="h-6 w-6" />
          </div>
          <h3 className="font-extrabold text-base">Time-Series Forecast</h3>
          <p className="text-xs text-slate-400">Predict upcoming 3-month spending with ML time-series modeling to prevent cash flow deficit.</p>
        </div>

        <div className="p-6 rounded-3xl border border-slate-800 bg-slate-900/60 backdrop-blur-md space-y-3">
          <div className="h-10 w-10 rounded-2xl bg-purple-500/10 text-purple-400 flex items-center justify-center">
            <Lock className="h-6 w-6" />
          </div>
          <h3 className="font-extrabold text-base">Bank-Grade Encryption</h3>
          <p className="text-xs text-slate-400">Zero-knowledge local vault AES-256 encryption protects your personal wealth record.</p>
        </div>
      </section>
    </div>
  );
};
