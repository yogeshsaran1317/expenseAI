import React, { useState } from "react";
import { useExpenseOS } from "../../context/ExpenseContext";
import { CURRENCIES } from "../../data/mockData";
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  Plus,
  Edit2,
  Check,
  ChevronRight,
  PieChart as PieIcon,
  ArrowUpRight,
  ArrowDownRight,
  Wallet,
  Zap,
} from "lucide-react";
import { DailyBatchExpenseModal } from "../expenses/DailyBatchExpenseModal";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
} from "recharts";

export const DashboardView: React.FC<{ onOpenAddExpense: () => void }> = ({ onOpenAddExpense }) => {
  const { metrics, expenses, incomeList, budgets, formatCurrency, user, setActiveTab, updateSalary, selectedCurrency } = useExpenseOS();
  const currSymbol = CURRENCIES[selectedCurrency]?.symbol || "₹";

  // Salary editing state
  const [isSalaryModalOpen, setIsSalaryModalOpen] = useState(false);
  const [isDailyBatchOpen, setIsDailyBatchOpen] = useState(false);
  const salaryItem = incomeList.find((i) => i.category === "Salary" || i.source.toLowerCase().includes("salary"));
  const currentSalary = salaryItem ? salaryItem.amount : (metrics.monthlyIncome || 0);
  const [newSalaryVal, setNewSalaryVal] = useState(currentSalary.toString());

  const handleSalarySave = (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = parseFloat(newSalaryVal);
    if (!isNaN(parsed) && parsed >= 0) {
      updateSalary(parsed);
      setIsSalaryModalOpen(false);
    }
  };

  const totalIncome = metrics.monthlyIncome;
  const totalExpenses = metrics.monthlyExpense;
  const remainingBalance = metrics.monthlySavings;
  const expensePercentage = totalIncome > 0 ? Math.round((totalExpenses / totalIncome) * 100) : 0;

  // Chart data
  const chartData = [
    { name: "Week 1", income: totalIncome, expense: Math.round(totalExpenses * 0.2), savings: totalIncome - Math.round(totalExpenses * 0.2) },
    { name: "Week 2", income: totalIncome, expense: Math.round(totalExpenses * 0.5), savings: totalIncome - Math.round(totalExpenses * 0.5) },
    { name: "Week 3", income: totalIncome, expense: Math.round(totalExpenses * 0.8), savings: totalIncome - Math.round(totalExpenses * 0.8) },
    { name: "Week 4", income: totalIncome, expense: totalExpenses, savings: remainingBalance },
  ];

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      {/* Header Section */}
      <header className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-2">
        <div>
          <h1 className="text-3xl font-light text-white tracking-tight">
            Financial <span className="font-bold">Summary & Calculations</span>
          </h1>
          <p className="text-neutral-400 text-sm mt-1">
            Real-time monthly salary vs. expense calculation engine
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={() => setIsDailyBatchOpen(true)}
            className="px-4 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-xs rounded-xl shadow-lg transition-all cursor-pointer flex items-center gap-1.5"
          >
            <Zap className="h-4 w-4" />
            Add Day's Expenses (Batch)
          </button>

          <button
            onClick={() => {
              setNewSalaryVal(currentSalary.toString());
              setIsSalaryModalOpen(true);
            }}
            className="px-4 py-2.5 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-semibold text-xs rounded-xl hover:bg-emerald-500/20 transition-all cursor-pointer flex items-center gap-1.5"
          >
            <Edit2 className="h-3.5 w-3.5" />
            Update Monthly Salary
          </button>

          <button
            onClick={onOpenAddExpense}
            className="px-4 py-2.5 bg-white text-black font-semibold text-xs rounded-xl hover:bg-neutral-200 transition-colors shadow-lg cursor-pointer flex items-center gap-1.5"
          >
            <Plus className="h-4 w-4" />
            Add Single
          </button>
        </div>
      </header>

      {/* Core Calculation Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Monthly Base Salary */}
        <div className="p-5 bg-neutral-950/60 border border-white/10 rounded-2xl backdrop-blur-xl relative overflow-hidden group hover:border-emerald-500/40 transition-all">
          <div className="flex items-center justify-between">
            <p className="text-neutral-400 text-[10px] uppercase tracking-widest font-bold font-mono">Monthly Salary</p>
            <button
              onClick={() => {
                setNewSalaryVal(currentSalary.toString());
                setIsSalaryModalOpen(true);
              }}
              className="text-neutral-500 hover:text-emerald-400 transition-colors text-[10px] font-mono underline"
            >
              Edit
            </button>
          </div>
          <p className="text-2xl font-bold text-emerald-400 tracking-tight font-mono mt-2">
            {formatCurrency(totalIncome)}
          </p>
          <div className="flex items-center gap-1 text-emerald-400 text-xs mt-2 font-medium">
            <TrendingUp className="h-3.5 w-3.5" />
            <span>Verified Inflow</span>
          </div>
        </div>

        {/* Calculated Total Expenses */}
        <div className="p-5 bg-neutral-950/60 border border-white/10 rounded-2xl backdrop-blur-xl hover:border-rose-500/40 transition-all">
          <p className="text-neutral-400 text-[10px] uppercase tracking-widest font-bold font-mono">Calculated Expenses</p>
          <p className="text-2xl font-bold text-rose-400 tracking-tight font-mono mt-2">
            -{formatCurrency(totalExpenses)}
          </p>
          <div className="flex items-center gap-1 text-rose-400 text-xs mt-2 font-medium">
            <TrendingDown className="h-3.5 w-3.5" />
            <span>{expenses.length} Expense Logs</span>
          </div>
        </div>

        {/* Net Remaining Balance */}
        <div className="p-5 bg-neutral-950/60 border border-white/10 rounded-2xl backdrop-blur-xl hover:border-blue-500/40 transition-all">
          <p className="text-neutral-400 text-[10px] uppercase tracking-widest font-bold font-mono">Remaining Balance</p>
          <p className="text-2xl font-bold text-white tracking-tight font-mono mt-2">
            {formatCurrency(remainingBalance)}
          </p>
          <div className="flex items-center gap-1 text-emerald-400 text-xs mt-2 font-medium">
            <ArrowUpRight className="h-3.5 w-3.5" />
            <span>{100 - expensePercentage}% Net Saved</span>
          </div>
        </div>

        {/* Expense Burn Ratio */}
        <div className="p-5 bg-neutral-950/60 border border-white/10 rounded-2xl backdrop-blur-xl">
          <p className="text-neutral-400 text-[10px] uppercase tracking-widest font-bold font-mono">Salary Burn Ratio</p>
          <div className="flex items-center gap-3 mt-2">
            <p className="text-2xl font-bold text-white font-mono tracking-tight">{expensePercentage}%</p>
            <div className="flex-1 h-2 bg-neutral-800 rounded-full overflow-hidden border border-white/5">
              <div
                className={`h-full rounded-full transition-all duration-300 ${
                  expensePercentage > 85 ? "bg-rose-500" : expensePercentage > 60 ? "bg-amber-500" : "bg-emerald-500"
                }`}
                style={{ width: `${Math.min(100, expensePercentage)}%` }}
              ></div>
            </div>
          </div>
          <p className="text-[10px] text-neutral-400 mt-2 font-mono">
            {expensePercentage > 85 ? "High Spending Alert" : "Balanced Cash Flow"}
          </p>
        </div>
      </div>

      {/* Middle Section: Calculated Trajectory & Category Expense Calculation */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Spending & Savings Chart */}
        <div className="lg:col-span-8 bg-neutral-950/60 border border-white/10 rounded-3xl p-6 backdrop-blur-xl flex flex-col justify-between shadow-xl">
          <div className="flex justify-between items-start mb-4">
            <div>
              <h3 className="text-base font-bold text-white">Monthly Cash Flow Progression</h3>
              <p className="text-xs text-neutral-400">Comparing Base Salary Inflow against Calculated Outflows</p>
            </div>
            <button
              onClick={() => setActiveTab("expenses")}
              className="text-xs font-mono font-bold text-emerald-400 hover:underline flex items-center gap-1 cursor-pointer"
            >
              View Expense Manager →
            </button>
          </div>

          <div className="h-64 w-full my-2">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="savingsGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#10b981" stopOpacity={0.4} />
                    <stop offset="100%" stopColor="#10b981" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="name" stroke="#525252" fontSize={11} tickLine={false} />
                <YAxis stroke="#525252" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#050505",
                    borderColor: "rgba(255,255,255,0.1)",
                    borderRadius: "12px",
                    color: "#fff",
                    fontSize: "12px",
                  }}
                  formatter={(val: any) => formatCurrency(Number(val))}
                />
                <Area type="monotone" dataKey="savings" stroke="#10b981" strokeWidth={3} fillOpacity={1} fill="url(#savingsGrad)" name="Remaining Balance" />
                <Area type="monotone" dataKey="expense" stroke="#f43f5e" strokeWidth={2} fillOpacity={0} name="Total Expenses" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Category Expense Calculations */}
        <div className="lg:col-span-4 bg-neutral-950/60 border border-white/10 rounded-3xl p-6 backdrop-blur-xl flex flex-col justify-between shadow-xl">
          <div>
            <h3 className="text-base font-bold text-white">Expense Category Breakdown</h3>
            <p className="text-xs text-neutral-400 mt-0.5">Calculated total spending per category</p>
          </div>

          <div className="space-y-3 my-4">
            {budgets.slice(0, 5).map((b) => {
              const catPercent = totalExpenses > 0 ? Math.round((b.spent / totalExpenses) * 100) : 0;
              return (
                <div key={b.category} className="space-y-1 text-xs">
                  <div className="flex justify-between items-center">
                    <span className="font-semibold text-neutral-300">{b.category}</span>
                    <span className="font-mono font-bold text-white">{formatCurrency(b.spent)} ({catPercent}%)</span>
                  </div>
                  <div className="w-full h-1.5 bg-neutral-900 rounded-full overflow-hidden border border-white/5">
                    <div
                      className="h-full bg-emerald-500 rounded-full"
                      style={{ width: `${Math.min(100, catPercent)}%` }}
                    ></div>
                  </div>
                </div>
              );
            })}
          </div>

          <button
            onClick={() => setActiveTab("budget")}
            className="w-full py-2 bg-white/5 hover:bg-white/10 text-white font-medium text-xs rounded-xl border border-white/10 transition-colors cursor-pointer text-center"
          >
            Manage All Budgets →
          </button>
        </div>
      </div>

      {/* Recent Transactions List */}
      <div className="bg-neutral-950/60 border border-white/10 rounded-3xl p-6 backdrop-blur-xl shadow-xl">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-base font-bold text-white">Recent Logged Expenses</h3>
          <button
            onClick={() => setActiveTab("expenses")}
            className="text-xs font-mono text-neutral-400 hover:text-white transition-colors cursor-pointer"
          >
            View All ({expenses.length}) →
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {expenses.slice(0, 4).map((exp) => (
            <div
              key={exp.id}
              className="flex items-center justify-between p-3.5 bg-white/5 rounded-2xl border border-white/5 hover:border-white/10 transition-all text-xs"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-neutral-800 flex items-center justify-center text-white font-bold text-xs border border-white/10">
                  {exp.title.charAt(0)}
                </div>
                <div>
                  <p className="font-bold text-white">{exp.title}</p>
                  <p className="text-[10px] font-mono text-neutral-400">{exp.category} • {exp.date}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-mono font-bold text-white">-{formatCurrency(exp.amount)}</p>
                <p className="text-[10px] text-rose-400 font-mono">Calculated Outflow</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Salary Update Modal */}
      {isSalaryModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <div className="w-full max-w-md rounded-3xl border border-white/10 bg-neutral-950 p-6 shadow-2xl space-y-4">
            <h3 className="text-lg font-bold text-white">Update Monthly Base Salary</h3>
            <p className="text-xs text-neutral-400">
              Enter your new monthly base salary amount to automatically recalculate net savings and expense burn ratio.
            </p>

            <form onSubmit={handleSalarySave} className="space-y-4">
              <div>
                <label className="block text-neutral-400 font-mono text-[10px] uppercase tracking-wider mb-1">
                  Monthly Base Salary Amount ({currSymbol})
                </label>
                <input
                  type="number"
                  step="0.01"
                  required
                  placeholder="e.g. 5000.00"
                  value={newSalaryVal}
                  onChange={(e) => setNewSalaryVal(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-base font-mono font-bold focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsSalaryModalOpen(false)}
                  className="flex-1 rounded-xl border border-white/10 py-2.5 font-bold text-xs text-neutral-400 hover:bg-white/5 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 rounded-xl bg-emerald-500 hover:bg-emerald-400 font-bold text-xs text-black py-2.5 transition-colors cursor-pointer"
                >
                  Update Salary
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <DailyBatchExpenseModal
        isOpen={isDailyBatchOpen}
        onClose={() => setIsDailyBatchOpen(false)}
      />
    </div>
  );
};
