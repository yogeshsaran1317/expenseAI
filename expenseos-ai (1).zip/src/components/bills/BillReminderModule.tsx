import React from "react";
import { useExpenseOS } from "../../context/ExpenseContext";
import { Calendar, CheckCircle2, Clock, AlertCircle, ShieldCheck } from "lucide-react";

export const BillReminderModule: React.FC = () => {
  const { bills, toggleBillPaid, formatCurrency } = useExpenseOS();

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
          <Calendar className="h-6 w-6 text-cyan-500" />
          Bill Calendar & Overdue Guard
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Automated due date tracking, late fee prevention & payment verification
        </p>
      </div>

      {/* Bill Items */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {bills.map((bill) => {
          const isOverdue = bill.status === "overdue";
          const isPaid = bill.status === "paid";

          return (
            <div
              key={bill.id}
              className={`rounded-3xl border p-5 shadow-xl flex flex-col justify-between transition-all ${
                isOverdue
                  ? "border-rose-300 dark:border-rose-800 bg-rose-50/30 dark:bg-rose-950/20"
                  : isPaid
                  ? "border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 opacity-80"
                  : "border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900"
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="font-extrabold text-sm text-slate-900 dark:text-white">{bill.title}</span>
                  {isPaid ? (
                    <span className="rounded-full bg-emerald-500/10 px-2.5 py-0.5 text-[10px] font-bold text-emerald-500 flex items-center gap-1">
                      <CheckCircle2 className="h-3 w-3" /> Paid
                    </span>
                  ) : isOverdue ? (
                    <span className="rounded-full bg-rose-500/10 px-2.5 py-0.5 text-[10px] font-bold text-rose-500 flex items-center gap-1">
                      <AlertCircle className="h-3 w-3" /> Overdue
                    </span>
                  ) : (
                    <span className="rounded-full bg-amber-500/10 px-2.5 py-0.5 text-[10px] font-bold text-amber-500 flex items-center gap-1">
                      <Clock className="h-3 w-3" /> Due Soon
                    </span>
                  )}
                </div>

                <p className="text-xs text-slate-500 dark:text-slate-400">Billed by: {bill.payee}</p>

                <div className="flex items-baseline justify-between mt-4">
                  <span className="text-xs text-slate-400">Due: <strong className="text-slate-900 dark:text-white">{bill.dueDate}</strong></span>
                  <span className="font-mono font-extrabold text-base text-slate-900 dark:text-white">
                    {formatCurrency(bill.amount)}
                  </span>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800/60 flex items-center justify-between text-xs">
                <span className="text-[10px] text-slate-400">
                  {bill.isAutoPay ? "⚡ Auto-Pay Enabled" : "Manual Payment"}
                </span>

                {!isPaid && (
                  <button
                    onClick={() => toggleBillPaid(bill.id)}
                    className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md shadow-emerald-500/20 cursor-pointer"
                  >
                    Mark Paid Now
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
