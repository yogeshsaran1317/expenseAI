import React, { useState } from "react";
import { ExpenseProvider, useExpenseOS, NavTab } from "./context/ExpenseContext";
import { Navbar } from "./components/layout/Navbar";
import { Sidebar } from "./components/layout/Sidebar";
import { MobileNav } from "./components/layout/MobileNav";
import { AuthModal } from "./components/auth/AuthModal";

// Views
import { DashboardView } from "./components/dashboard/DashboardView";
import { ExpenseManagement } from "./components/expenses/ExpenseManagement";
import { IncomeModule } from "./components/income/IncomeModule";
import { AICfoAdvisor } from "./components/ai/AICfoAdvisor";
import { AnalyticsView } from "./components/analytics/AnalyticsView";
import { BudgetModule } from "./components/budget/BudgetModule";
import { GoalsModule } from "./components/goals/GoalsModule";
import { SubscriptionManager } from "./components/subscriptions/SubscriptionManager";
import { BillReminderModule } from "./components/bills/BillReminderModule";
import { CalculatorsModule } from "./components/calculators/CalculatorsModule";
import { GamificationModule } from "./components/gamification/GamificationModule";
import { FinancialJournal } from "./components/journal/FinancialJournal";
import { SecurityModule } from "./components/security/SecurityModule";
import { AdminPanel } from "./components/admin/AdminPanel";
import { LandingPage } from "./components/landing/LandingPage";

const MainAppContent: React.FC = () => {
  const { activeTab, setActiveTab } = useExpenseOS();

  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  const renderActiveView = () => {
    switch (activeTab) {
      case "dashboard":
        return <DashboardView onOpenAddExpense={() => setActiveTab("expenses")} />;
      case "expenses":
        return <ExpenseManagement />;
      case "income":
        return <IncomeModule />;
      case "ai-cfo":
        return <AICfoAdvisor />;
      case "analytics":
        return <AnalyticsView />;
      case "budget":
      case "budgets":
        return <BudgetModule />;
      case "goals":
        return <GoalsModule />;
      case "subscriptions":
        return <SubscriptionManager />;
      case "bills":
        return <BillReminderModule />;
      case "calculators":
        return <CalculatorsModule />;
      case "gamification":
        return <GamificationModule />;
      case "journal":
        return <FinancialJournal />;
      case "security":
        return <SecurityModule />;
      case "admin":
        return <AdminPanel />;
      case "landing":
        return <LandingPage onLaunchApp={() => setActiveTab("dashboard")} />;
      default:
        return <DashboardView onOpenAddExpense={() => setActiveTab("expenses")} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#050505] text-neutral-200 font-sans transition-colors duration-200 antialiased selection:bg-emerald-500 selection:text-black">
      {/* Top Navbar */}
      <Navbar
        onOpenAuth={() => setIsAuthOpen(true)}
        onOpenAddExpense={() => setActiveTab("expenses")}
        onToggleSidebar={() => setIsDrawerOpen(!isDrawerOpen)}
      />

      <div className="flex pt-16">
        {/* Desktop Sidebar & Mobile Drawer */}
        <Sidebar isOpenMobile={isDrawerOpen} onCloseMobile={() => setIsDrawerOpen(false)} />

        {/* Main Content View Container */}
        <main className="flex-1 lg:pl-64 min-h-[calc(100vh-4rem)] p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full">
          {renderActiveView()}
        </main>
      </div>

      {/* Mobile Bottom Navigation */}
      <MobileNav onToggleDrawer={() => setIsDrawerOpen(!isDrawerOpen)} />

      {/* Auth Modal */}
      <AuthModal isOpen={isAuthOpen} onClose={() => setIsAuthOpen(false)} />
    </div>
  );
};

export function App() {
  return (
    <ExpenseProvider>
      <MainAppContent />
    </ExpenseProvider>
  );
}

export default App;
